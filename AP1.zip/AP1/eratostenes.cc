#include <vector>
#include <iostream>
using namespace std;


void eratostenes (int n, vector <bool>& prime){
	if (not prime[n]) cout<< n << " is not prime"<<endl;
	else cout<< n << " is prime"<<endl;
}

vector <bool> llista (int n){
	vector <bool> prime (n,true);
	if (n>0) prime [0] = false;
	if (n>1) prime [1] = false;

	int i=2;
	while(i*i<=n){
		if (prime[i]){
			for (int j=i+i; j<=n; j=j+i){
				prime [j]=false;
			}
		}
		++i;
	}
	return prime;
}

int main (){
	int n;
	vector <bool> prime = llista (1000001);

	while (cin>>n) eratostenes(n,prime);

}