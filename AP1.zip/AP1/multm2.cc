#include <vector>
#include <iostream>
using namespace std;


typedef vector< vector<int> > Matrix;

Matrix product(const Matrix& A, const Matrix& B){
    int filesA = A.size();
    int columnesAfilesB = A[0].size();
    int columnesB = B[0].size();

    Matrix res (filesA,vector<int>(columnesB));

    for (int i=0; i<filesA; ++i){
        for (int j = 0; j<columnesB; ++j){
            int sum=0;
            for (int k = 0; k<columnesAfilesB; ++k){
                sum = sum + A[i][k]*B[k][j];
            }
            res[i][j] = sum;
        }
    }

    return res;
}


int main ()
{
    int p, q, r;
    while (cin >> p >> q >> r) {
        Matrix A(p,vector<int>(q));
        Matrix B(q,vector<int>(r));
        for (int i=0; i<p; ++i) {
            for (int j=0; j<q; ++j) {
                cin >> A[i][j];
        }   }
        for (int i=0; i<q; ++i) {
            for (int j=0; j<r; ++j) {
                cin >> B[i][j];
        }   }
        Matrix C = product(A,B);
         cout << endl;
        for (int i=0; i<p; ++i) {
            for (int j=0; j<r; ++j) {
                cout << C[i][j] << " ";
            }
            cout << endl;
        }   
        cout << endl;
    }
}
