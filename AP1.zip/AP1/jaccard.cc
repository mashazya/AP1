#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void jaccard (int n, int m, const vector <int>& v){
	int p = v.size();
	double suma = n+m-p;
	double jaccard = p/suma;
	cout<< jaccard<<endl;


}

void compara (vector <int> & v1, vector <int> & v2, int n, int m){
	int i = 0;
	int j = 0;
	vector <int> v;
	while (i<v1.size() and j<v2.size()){
		if (v1[i]==v2[j]){
			v.push_back(v1[i]);
			++i;
			++j;
		}

		if (v1[i]<v2[j]){
			while (v1[i]<v2[j]) ++i;
		}

		if (v1[i]>v2[j]){
			while (v1[i]>v2[j]) ++j;
		}
	}

	jaccard(n,m,v);


}


int main (){
	cout.setf(ios::fixed);
	cout.precision(3);
	int n,m;
	while(cin >> n){
		vector <int> v1 (n);
		for (int i=0; i<n; ++i){
			cin>> v1[i];
		}

		cin >> m;
		vector <int> v2 (m);
		for (int i=0; i<m; ++i){
			cin>> v2[i];
		} 
		compara(v1,v2, n, m);
	}
}