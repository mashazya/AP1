#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Rectangle {
	int width;
	int height;
};

void escriu (const vector <Rectangle>& rectangles){
	for (int i = 0; i<rectangles.size(); ++i){
		cout<< rectangles[i].width << " "<< rectangles[i].height <<endl;
	}

}

bool compara (const Rectangle & a, const Rectangle& b){

	if (a.width * a.height != b.width * b.height) return a.width * a.height<b.width * b.height;
	if (a.width * a.height == b.width * b.height){
		if(2*(a.width + a.height) != 2*(b.width + b.height)) return 2*(a.width + a.height) > 2*(b.width + b.height);
	}
	return a.width<b.width;
}

void ordena (vector <Rectangle>& rectangles){
	sort (rectangles.begin(), rectangles.end(), compara);
	escriu (rectangles);
}

int main (){
	int n;
	while(cin>>n){
		vector <Rectangle> rectangles (n);
		for (int i=0; i<n; ++i){
			cin >> rectangles[i].width >> rectangles[i].height;
		}
		ordena (rectangles);
		cout<< "----------" <<endl;
	}

}