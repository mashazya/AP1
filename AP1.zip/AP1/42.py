from jutge import read

print ("42")