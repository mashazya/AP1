#include <iostream>
#include <vector>
#include <cassert>
using namespace std;

producte_escalar (const vector <double>& x, const vector <double>& y) { // el nom del vector (x,y) es posa darrere
	// passar el vector per referencia constant no deixa que es modifiquin les dades del vector dintre del cell (per seguretat)
	assert (x.size()) == y.size; // mida de les components ha de ser =
	double s = 0.0;
	for (int i = 0; i<x.size(); ++i){
		s=s+x[i] * y[i];
	}

	return s;
}

double modul (vector<double> x) {
	return sqrt (producte_escalar(x,x));
}

double minim (const vector <double>& v){
	assert (v.size() !=0);
	double min = v[0];
	for (int i = 1; i< v.size(); ++i){
		if (v[i]< min) min = v[i];
	}
	return min;
}

bool capicua(const vector <double>& v){
	int n = v.size();
	for (int i = 0; i <n/2; ++i){
		if (v[i] != v[n-i-1]) return false;
	}
}

void escalar (vector<double>&, double c){
	for (int i = 0; i< v.size(); ++i){
		v[i] = v[i] *c;
	}
}

int main (){
	int n;
	cin >> n;

	vector <double> v1 (n); // vector v1 de mida n
	vector <double> v2 (n);
	for (int i=0; i<n; ++i){
		cin >> v1[i];
	}
	for (int i=0; i<n; ++i){
		cin >> v2[i];
	}

	cout << producte_escalar (v1,v2) << endl;


}