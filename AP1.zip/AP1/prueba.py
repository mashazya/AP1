from jutge import *

def hh(v):
	v=sorted(v)
	print(v)

def main():

	v=[0,1,3,4,5,75432,2,0]
	hh(v)


main()
