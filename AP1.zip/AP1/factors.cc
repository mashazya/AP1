#include <iostream>
using namespace std;

void factor(int n, int& f, int& q){

    int k=2;
    q=0;
    f=n;
    
 int i = 0;
    while (k*k<=n){
        while (n%k==0 ){
            ++i;
            n=n/k; 
        }
        if (i>q){
            q=i;
            f=k;
             
        }
    ++k;
    i=0;
    }
     if (f==n) q=1;
}

int main (){
    int n,f,q;
    cin >> n;
    factor (n,f,q);
}