#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;


int main () {


cout.setf(ios::fixed);
cout.precision(4);

double x;
cin >> x;

double p;
double a;
cin >> p;

while (cin >>a) {
	p=(p*x)+a;
}

cout << p << endl;

}