#include <iostream>
#include <cassert>
using namespace std;

bool primer(int n){
	if (n==2) return true;
	if (n==0 or n==1) return false;
	int x=1;
	while (x*x<n){
		++x;
		if (n%x==0) return false;
	}
	return true;
}


int sum_of_digits(int x){
	int sum;

	if (x>0){
		return sum= x%10 +sum_of_digits(x/10);
	}
	return false;
}


bool is_perfect_prime(int n){
	if (n==0)return false;
	if (not primer(n)) return false;
	if (n>0){
		n=sum_of_digits(n);
		if (n/10>0 and primer(n)) return is_perfect_prime(n);
		else if (primer (n)==false) return false;
	}
	return true;

}



int main (){
	int n;
	cin >> n;
	cout<< is_perfect_prime(n) <<endl;
	
}