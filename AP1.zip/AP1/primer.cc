#include <iostream>
using namespace std;
int main () {


	int n;
	cin >> n;
	int p ;
	if (n >= 2) p=1;
	else p =0;



		int i = 2;
		while (i < n and p==1) {
			if (n%i =0) {
				p=0;
			}
			else {
				++i;
			}

		}

	if (p==1) cout "es primer" << endl;
	else cout << "no es primer" << endl;




}