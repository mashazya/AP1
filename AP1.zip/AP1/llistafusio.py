#ordenacio per fusio python
from jutge import read
import random

def ordenacio_per_fusio(v,e,m,d):
	r = []
	i,j = e,m+1
	while



def main ():
	n= read (int)
	v=[random.random() for i in range (n)]
	ordenacio_per_fusio (v)
