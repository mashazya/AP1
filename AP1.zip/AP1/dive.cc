#include <iostream>
using namespace std;

void div (int n){
	int i=1;
	int a;
	
	cout << "divisors of "<< n<< ":";
	while (i*i<n){
		if(n%i==0){
			cout<< " " << i;
			a=i;
		}
		++i;
	}
	while (i>0){
		if(n%i==0 and n/i!=a){
			cout <<  " " << n/i;
		}
		--i;
	}

}
int main (){
	int n;
	while (cin >> n){
		div(n);
		cout<<endl;
	}
}


