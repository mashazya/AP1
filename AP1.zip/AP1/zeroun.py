from jutge import read

def zeros_o_uns(n):
	o=0
	i=0
	while n>0:
		if n%2==0:
			o=o+1
		else:
			i=i+1
		n=n//2
		

	if o>i:
		return('0')
	if i>o:
		return('1')
	
	return('2')

def main ():
	n=read(int)
	print(zeros_o_uns(n))

main()
	