#include <iostream>
using namespace std;

int max2 (int a, int b) {
	if (a>b) return a;
	return b;

}

int max3 (int a, int b, int c) {
	if (a > (max2 (b,c))) return a;
	return max2 (b,c);
}

int max4 (int a, int b, int c, int d){
	if (a > (max3 (b, c, d))) return a;
	return max3 (b,c,d);

}

int main () {
	int a, b, c, d;
	cin >> a >> b >> c >> d;
	cout << max4(a,b,c,d) << endl;


}