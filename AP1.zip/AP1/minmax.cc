#include <iostream>
using namespace std;


void min_max(int a, int b, int& mn, int& mx){
	if (a>b){
		mx = a;
		mn = b;
	} 
	else{
		mx = b;
		mn = a;
	}
}
int main (){
	int x, y, min,max;
	cin >> x >> y;
	min_max (x,y, min, max);
}