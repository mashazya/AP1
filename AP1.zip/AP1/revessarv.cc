#include <iostream>
#include <sting>
#include <algorithm> // per que funcioni el swap
using namespace std;


int revessar (vector <int>& v){
	int n = v.size();
	for (int i = 0; i<n/2; ++i){
		swap (v[i], v[n-i-1]);
	}
}

int main (){

	vector <int> v = {4,7,8,3};
	revessar (v);
	for (int x: v) cout << x << endl;

}