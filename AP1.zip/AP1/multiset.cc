#include <iostream>
#include <vector>
using namespace std;


void escriu(const vector <int> &v, int n){
	cout<<"{";
	bool primera=true;
	for (int i=0; i<n; ++i){
		for (int j=0; j<v[i]; ++j){
			if (not primera) cout<<',';
			else primera = false;
			cout<< i+1;
		}
	}
	cout<<"}"<<endl;

}

void genera(int n, int min_reps, int max_reps, vector <int> &v, int  i){
	if (i==n) escriu(v,n);
	else {
		for (int j=min_reps; j<=max_reps; ++j){
			v[i]=j;
			genera(n,min_reps,max_reps,v,i+1);
		}
	}

}

int main (){
	int n;
	int min_reps;
	int max_reps;

	cin>>n>>min_reps>>max_reps;
	vector <int> v (n); 
	genera(n,min_reps,max_reps,v,0);
}