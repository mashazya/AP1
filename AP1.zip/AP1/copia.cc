#include <typeinfo>
#include <iostream>    
#include <string>    
#include <vector>
#include <algorithm>   
using namespace std;

struct Paraula {
    string word;
    int repe;
};

bool menor(const Paraula& a, const Paraula& b) {
    if (a.repe != b.repe) return a.repe < b.repe;       // camp més discriminador
	return a.word > b.word;       // següent camp més discriminador
}


void comparar_frequencia (vector <Paraula>& comptador, const vector <string>& v, int n, int k){
	sort(comptador.begin(), comptador.end(), menor);
	int i = comptador.size()-1;
	while (k>0){
		cout<< comptador[i].word<<endl;
		--i;
		--k;
	}
	cout<< "----------" <<endl;
}

void ordenar_vector(vector <string>& v){
	sort(v.begin(), v.end());
}


int main(){
	int n,k;
	while(cin>>n>>k){
		vector <string> v(n);
		vector <Paraula> comptador(0);
		for (int i = 0; i<n; ++i){
			cin>>v[i];
		}
		ordenar_vector(v);
		comptador.push_back({v[0],1});
		int p=0;
		for (int i = 0; i<n-1; ++i){
			if (v[i]!=v[i+1]){
				comptador.push_back({v[i+1],1});
				++p;
			}
			else ++comptador[p].repe;

		}
		
		comparar_frequencia(comptador,v,n,k);
	}
	

}