from jutge import read


x,y,z= read (int,int,int)

if x > y:
	m=x
else:
	m=y

if z>m:
	m=z

print (m)