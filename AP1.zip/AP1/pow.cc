#include <iostream>
#include <cmath>
using namespace std;

int main (){
	cout.setf (ios::fixed);
	cout.precision(0);
	int a,b;
	while (cin >> a >> b){
		cout << fixed << pow (a,b) << endl;
	}
}