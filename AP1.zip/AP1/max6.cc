#include <iostream>
using namespace std;
int main () {

	int x;
	cin >> x;

	int m = x;
	int i = 0;
	while (i<6) {
		cin >> x;

		if (i == 0 or x>m) m=x;
		++i;


	}
	cout << m << endl;




}