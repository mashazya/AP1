#include <iostream>
using namespace std;

void minuts (int m,int h){
	int x=0;
	if (m==0) x=4;
	if (m==15) x=1;
	if (m==30) x=2;
	if (m==45) x=3;


	if (x==0) {
		cout << "silencio hasta las ";
		if (m<15){
			m=15;
		}
		if (m>15 and m<30){
			m=30;
		}
		if (m>30 and m<45){
			m=45;
		}
		if (m>45) {
			m=0;
			++h;
			if (h==24) h=0;
		}

		if (h==0 or h<10) cout << "0"<<h << ":";
		else cout << h << ":";
		
		if (m==0) cout << "0" << m;
		else cout << m;
	}

	while (x>0){
		if (x!=1 or m==0) cout << "ding ";
		else cout << "ding";
		--x;
	}

}
void hores (int h){
	if (h>12) h=h%12;
	if (h==0) h=12;
	while (h > 0){
		if (h!=1) cout << "dong ";
		else cout << "dong";
		--h;
	}
	
}


void campana (int h, int m){

	minuts(m,h);
	if (m==0) hores(h);
	cout << endl;
}

int main (){
	int h,m;
	while (cin >> h >> m){
		campana (h,m);
	}
	
	
}