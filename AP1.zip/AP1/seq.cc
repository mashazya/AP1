#include <iostream>
#include <string>
using namespace std;


int main (){
	string (n);
	cin >> n;
	string (s) = n;
	
	int i = 1;
	int max=1;

	while (cin >> s){
		if (s==n){
			++i;
			
			if (max<=i) {

				max = i;
				
			}
		}
		
		if (s!=n) i=0;

	}

	cout << max << endl;

}