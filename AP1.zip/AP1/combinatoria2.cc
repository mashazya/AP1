#include <vector>
#include <iostream>
using namespace std;

void escriu (const vector <int>&v, const vector <string>& paraules){
	int n = v.size();
	for (int i = 0; i<n; ++i) {
		if (v[i]== 1){
			cout<<paraules[i]<< " "
		}
	}
	cout<<endl;
}

void genera (vector<int>&v, int i, const vector <string>& paraules){
	int n =v.size();
	if (i==n){
		escriu(v,paraules);
	}
	else{
		v[i]=0;
		genera(v,i+1,paraules);
		v[i]=1;
		genera(v,i+1,paraules);
	}


}

int main (){
	vector <string> paraules;
	string paraula;
	while (cin>>paraula) {
		paraules.push_back(paraula);
	}
	int n = paraules.size();
	vector<int> v(n);

	genera(v, 0,paraules);
}