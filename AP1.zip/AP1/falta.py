from jutge import read

def suma (n):
	suma =0
	while n>0:
		suma=suma+n
		n=n-1
	return suma

def main():

	n = read (int)
	while n is not None and n>0:
		if n==1:
			print ("1")
			n=read (int)
		else:
			s= suma (n)
			a=read (int)
			i=1
			s=s-a
			while a is not None and i!=(n-1):
				i=i+1
				a=read (int)
				s=s-a
			print (s)
			n=read (int)

main ()
