from jutge import read

def up (n):
	z = 1
	y = n
	i=z
	k=n
	x=0
	while k > 1:
		while i < n:
			i=i+1
			print(' ', end='')
		
		while x<y:
			x=x+1
			print ('X',end='')
		
		z=z+1
		y=y+2
		x=0
		i=z
		k=k-1
		print ()
	

def pinta_mig (n):
	k = n
	i = n+(2*(n-1))
	while k>0:
		while i>0:
			print('X',end='')
			i=i-1
		
		i=n+(2*(n-1))
		k=k-1
		print ()
	


def down (n):
	m = 1
	k = 0
	i = n
	x = 0
	y = n+(2*(n-1))-2

	while i>1:
		while k<m:
			k=k+1
			print(' ',end='')
		
		while x<y:
			x=x+1
			print('X',end='')
		
		x=0
		y = y-2
		k=0
		m=m+1
		i=i-1
		print()

def oct (n):
	up (n)
	pinta_mig (n)
	down(n)

def main ():

	n=read(int)
	while n is not None:
		oct(n)
		n=read(int)
		if n is not None:
			print('')


main ()