#include <iostream>
#include <vector>
#include <string>
using namespace std;


void escriu (const vector <int>& comptador, const vector <string>& v){
	int n = comptador.size();
	int k =  0;
	cout<< "(";
	for (int i = 0; i<n; ++i){
		if (k>0) cout<< ",";
		cout<< v[comptador[i]];
		++k;
	}
	cout<< ")"<< endl;
}


void genera(vector <int>& comptador, vector <bool>& b, vector <string>& v, int i){
	int n = comptador.size();

	if (i==n){
		escriu(comptador,v);
	}
	else {
		for (int j = 0; j<n; ++j){
			if (not b[j]){
				comptador[i]=j;
				b[j]=true;
				genera(comptador,b,v,i+1);
				b[j]=false;
			}
		}
	}
}


int main (){
	int n;
	cin>>n;
	vector <string> v (n);
	for (int i = 0; i<n; ++i){
		cin>>v[i];
	}
	vector <int> comptador(n);
	vector <bool> b (n,false);
	genera (comptador,b,v,0);

}