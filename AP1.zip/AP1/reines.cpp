#include <iostream>
#include <vector>

using namespace std;

void escriure(int n, const vector<int> q){
	for (int i = 0; i<n;  ++i){
		for (int j = 0; j<n; ++j){
			if(q[i]==j) cout<< 'o';
			else cout<<'.';
		}
		cout<< endl;
	}
	cout<<endl;
}

int diag1(int i, int j){
	return i+j;
}
int diag2 (int i, int j, int n){
	return n-j-1+i;
}

bool possible (int n, vector <int>& q, vector<bool>&r, int j){
	
	return not r[j] and not diag;
}

void totes_reines (int n, vector <int>& q, vector<bool>&r, int i){
	if (i==n){
		escriure(n,q);
	}
	else{

		for (int j=0; j<n; ++j){
			if (possible(n,q,r,d1,d2,i,j)){
				q[i]=j;
				r[j]=true;
				d1[diag1(i,j)]=true;
				d2[diag2(i,j),n]=true;
				totes_reines(n,q,r,d1,d2,i+1);
				r[j]=false;
				d1[diag1(i,j)]=false;
				d2[diag2(i,j),n]=false;
			}
		}
	}
}

int main (){
	intn n;
	cin>> n;
	vector<int> q(n);
	vector<bool> r(n,false);
	vector<bool> d1(2*n-1,false);
	vector<bool> d2(2*n-1,false);
	totes_reines(n,q,r,d1,d2,0);
}



