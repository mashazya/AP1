#include <iostream>
#include <vector>
#include <string>
using namespace std;

void invertir (string v){
    int n = v.size()-1;
    for (int i = n; i>=0; --i){
        cout<<v[i];
    }
    cout<<endl;

}

int main() {
    string v;
    while (cin >> v){
        invertir (v);
    }
    
}


