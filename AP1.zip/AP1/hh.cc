#include <vector>
#include <iostream>
#include <string>
using namespace std;
using Matrix = vector<vector<int>>;


void escriu_dislikes (int n, const Matrix& M){
	int suma=0;
	for (int i=0; i<n; ++i){
		for (int j=0)
	}

}

genera (){
	if (i==n){
		return escriu();
	}
	for (int i = 1; n; ++i){
		v[i]=
	}
}


int main (){
	int n;
	cin>>n;
	vector <string> names(n);
	for (int i = 0; i<n; ++i){
		cin>> names[i];
	}
	Matrix M = (n, vector <int> (n));
	for (int i = 0; i<n; ++i){
		for (int j = 0; j<n; ++j){
			cin>> M[i][j];
		}
	}
	vector <int> v(n);

}