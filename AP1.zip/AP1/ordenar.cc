#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>

using namespace std;

int pos_minim (vector<double>& v, int i){
	int m = i;
	for (int j = i+1; j<v.size(); ++j){
		if (v[j] < v[m]){
			m=j;
		}
	}
	return m;
}


void ordenar_seleccio (vector<double>& v){
	int n = v.size();
	for (int i = 0; i<n; ++i){
		int m = pos_minim (v,i);
		swap (v[i],v[m]);
	}
}

void insereix (vector <double>& v, int i){
	int j = i-1;
	while (j>=0 and v[j]>v[j+1]){
		swap (v[i],v[j+1]);
		--j;
	}
	
}

void ordenar_insercio (vector<double>& v){
	int n = v.size();
	for (int i = 1; i<n; ++i){
		insereix (v,i);
	}
}

int main (){
	int n;
	cin >> n;
	vector <double> v = (n);
	for (double& x : v) x = rand ()/double (RAND_MAX);
	ordenar (v);
	for (double x : v) cout << x<< " ";
	cout << endl;
}