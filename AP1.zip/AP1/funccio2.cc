#include <iostream>
using namespace std;

int factorial (int n) {
	int f = 1;
	for (int i = 2; i<=n; i++){
		f*=i;
	}
	return f;

}

int nombre_combinatori (int n, int m) {

	return factorial (n)/ (factorial (m) * factorial (n-m));
}

bool es_primer (int n) {
	if (n<=1) return false;
	int i = 2;
	while (i<n) {
		if (n%i == 0) return false;
		i ++;
	}

	return true;


}

int main () {
	int n;
	cin >> n;
	cout << factorial << endl;


}