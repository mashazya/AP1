from jutge import *

def pinta_octagon(n):
	x=n
	blanc=n-1
	for i in range (n):
		print(" "*blanc,end="")
		print('X'*x)
		blanc=blanc-1
		x=x+2

	x=x-2

	for i in range (n-2):
		print ('X'*x)

	blanc=blanc+1

	for i in range (n):
		print(" "*blanc,end="")
		print('X'*x)
		blanc=blanc+1
		x=x-2




def main():
	n=read(int)
	while (n is not None):
		pinta_octagon(n)
		print("")
		n=read (int)
main()
