#include <iostream>
using namespace std;

int main () {
	string c = "/ @";
	cout << c << endl;

}