#include <iostream>
using namespace std;

void up (int n){
	int z = 1;
	int y = n;
	int i=z;
	int k=n;
	int x=0;
	while (k>1){
		while (i<n){
			++i;
			cout << " ";
		}
		while (x<y){
			++x;
			cout << "X";
		}
		++z;
		y=y+2;
		x=0;
		i=z;
		--k;
		cout<< endl;
	}
}
void pinta_mig (int n){
	int k = n;
	int  i = n+(2*(n-1));
	while(k>0){
		while (i>0){
			cout <<"X";
			--i;
		}
		i=n+(2*(n-1));
		--k;
		cout << endl;
	}
}

void down (int n){
	int m = 1;
	int k = 0;
	int i = n;
	int x = 0;
	int y = n+(2*(n-1))-2;

	while (i>1){
		while (k<m){
			++k;
			cout << " ";
		}
		while (x<y){
			++x;
			cout << "X";
		}
		x=0;
		y = y-2;
		k=0;
		++m;
		--i;
		cout << endl;
	}

}

void oct (int n){
	up (n);
	pinta_mig (n);
	down(n);
	cout<<endl;



}

int main (){
	int n;
	while (cin >> n){
		oct(n);
	}
}