#include <iostream>
using namespace std;


int base (int n, int b){
	int r = n%b;// 2/0/3
	int sum;
	if(n>0) return sum = r+ base(n/b,b)*10;
	return false;
}
bool comprovar (int n,int b){

	int k,m;
	
	m = n%10;
	k = (n%100)/10;

	if (n>0){
			if (m>=b/2 and k<b/2) return comprovar(n/100,b);
			else return false;
		}
	return true;
}

bool es_xupiguai(int n, int b){
	if (n==0) return false;
	n = base(n,b);
	if (comprovar (n,b)) return true;
	return false;

}

int main (){
	int n,b;
	cin>> n>>b;
	cout << es_xupiguai(n,b)<< endl;
}