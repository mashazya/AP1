#include <iostream>
using namespace std;

int main (){
	int a;
	int i = 0;
	while (cin >> a){
		while (a!=1){
			if (a%2==0){
				a=a/2;
				++i;
			}
			else {
				a=(a*3)+1;
				++i;
			}
			
		}
		cout << i << endl;
		i=0;
	}
}