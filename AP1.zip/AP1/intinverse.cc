#include <iostream>
using namespace std;
int main () {
	
	int x,y;
	cin >> x >> y;


	if (x<y){

		while (y>=x) {
		cout << y << endl;
		y = y-1;
	}

	}

	else {

		while (y <= x) {
		cout << x << endl;
		x = x-1;
		}
	}




}