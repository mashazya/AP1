#include <iostream>
#include <vector>
#include <string>
#include  <algorithm>
using namespace std;

void escriu(const vector<int>& v){
	for (int i=0; i<v.size(); ++i){
		cout<<v[i];
	}
	cout<<endl;
}


void ordena_creix(string& n){
	sort(n.begin(),n.end());
}

bool compara ( char& a,  char& b){
	return a>b;
}

void ordena_decr(string& n){
	sort(n.begin(),n.end(),compara);
}

vector <int> resta (string k, string n){
	int s=k.size();
	vector<int>resta(s,0);
	for (int i=s-1; i>=0; --i){
		if (k[i]<n[i]){
			resta[i]=k[i]+10-n[i];
			++n[i-1];
		}
		else resta[i]=k[i]-n[i];
	}
	return resta;
}

int main(){
	string n;
	while (cin>>n){
		string min=n;
		ordena_creix(min);
		string max=n;
		ordena_decr(max);
		vector<int> d1=resta(n,min);
		vector<int> d2=resta(max,n);
		if (d1>d2) escriu (d1);
		else  escriu (d2);
	}
}

