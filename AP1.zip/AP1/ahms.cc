#include <iostream>
using namespace std;

void decompose(int n, int& h, int& m, int& s){

     h = n / 3600;
     m = (n % 3600) / 60;
     s = (n % 3600) % 60;
	
}

int main (){
    int x, h, m, s;
    cin >> x;
    decompose (x,h,m,s);
}

