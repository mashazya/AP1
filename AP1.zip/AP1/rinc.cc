#include <iostream>
#include <algorithm>
using namespace std;

bool is_increasing(int n){
	
	int x;
	int y;
	if (n/10>0){
		x = n%10;
		y = (n%100)/10;
		if (y<=x){
			return is_increasing (n/10);
		}
		if (y>x) return false;
	}
	return true;

	
}

int main (){
	int n;
	cin >> n;
	cout<< is_increasing(n)<<endl;
	
}