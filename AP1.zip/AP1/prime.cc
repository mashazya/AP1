#include <iostream>
using namespace std;

int main () {
	int n;
	int a;
	int i = 2;
	bool primer = true;
	cin >> n;
	while (n>0){
		cin >> a;
		if (a==0 or a==1) primer = false;
		while (i*i<=a and primer and a>0){
			if (a%i==0){
				primer = false;
			}
			++i;
		}

		if (primer==true) cout<< a << " is prime"<< endl;
		else cout<< a << " is not prime"<< endl;

		--n;
		primer=true;
		i=2;
	}
}