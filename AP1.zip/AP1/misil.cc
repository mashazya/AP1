#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<char>>; 

void write (Matrix M, int f, int c){
	for(int i=0; i<f; ++i){
		for(int j= 0; j<c; ++j){
			cout<< M[i][j];
		}
	cout<<endl;
	}
}

void misil (Matrix& M, int f, int c, int i, int j){

	while(i!=f and j!=c){
		M[i][j]='X';
		++i;
		++j;
	}

	if (i==f and j!=c){
		--i;
		--j;

		while(j!=c-1 and i!=0){
			--i;
			++j;
			M[i][j]='X';
		}

	}
	/*if (j==c-1 and i!= f-1 and i!=0){
		while (i!=0){
			--i;
			--j;
			M[i][j]='X';
		}
	}

	if ((i==0 and j!=0)or(j==c and i!=f)){
		if(j==c) {
			--j;
			--i;
		}
		while (j!=0){
			++i;
			--j;
			M[i][j]='X';
		}
	}

	if (i>=f-1 and j>=c-1) {
		write(M,f,c);
		return;
	}
	if (i==0 and j==c-1) {
		write(M,f,c);
		return;
	}
	if (i==f-1 and j==0) {
		write(M,f,c);
		return;
	}
		else misil (M,f,c,i,j);*/

		write(M,f,c);
}

int main(){
int f,c;
cin>>f>>c;
Matrix M (f, vector<char>(c));
for (int i=0; i<f; ++i){
	for (int j=0; j<c; ++j){
		M[i][j] = '.';
	}
}

misil(M,f,c,0,0);
}


