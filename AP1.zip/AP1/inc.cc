#include <iostream>
using namespace std;


bool is_increasing(int n){
	int i = 10;
	if (n%i >= (n/10)%(i*10)){
		is_increasing (n/10);
		return true;
	}
	return false;
}

int main () {
	int n;
	cin >> n;
	cout << is_increasing(n) << endl;

}