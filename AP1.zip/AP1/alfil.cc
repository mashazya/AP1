#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<char>>;

bool cantonada (int i , int j, int f, int c){
	return ((i==0 and j==c-1) or  (i==f-1 and j==c-1) or (i==f-1 and j==0));
}

Matrix rebotar(int f, int c){
	Matrix M (f, vector<char> (c,'.'));
	int i = 0;
	int j = 0;//posicio inicial
	int hor, ver;// direccio en la q va l'alfil
	//1,1 -> dreta abaix, -1,-1 esquerra adalt
	M[0][0]='X';
	while(not cantonada(i,j,f,c)){//mentres no arribem a una cantonada seguira el programa
		//per moure l'afi; cal saber la direccio de moure
		if (i==0) ver = 1;//per moure cap abaix
		if (i==f-1)  ver = -1;
		if (j==0) hor = 1;
		if (j==c-1) hor = -1;

		//moviment
		i=i+ver; // si ver = 1 i=i+1 (baixa)
		j=j+hor;

		//marquem casella
		M[i][j]='X';

	}
	return M;

}

void escriure (Matrix& M, int f, int c){
	for (int i = 0; i<f; ++i){
		for (int j =0; j<c; ++j){
			cout<< M[i][j];
		}
		cout<<endl;
	}
}

int main(){
	int f,c;
	while(cin>>f>>c){
		Matrix M=rebotar(f,c);
		escriure (M,f,c);
		cout<<endl;
	}
}