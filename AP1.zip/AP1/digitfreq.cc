#include <iostream>
#include <vector>
#include <cmath>
#include  <algorithm>
using namespace std;

int canviar_base(int & r, int b, int n, int i, vector <int> & nombres){
	if (n>0){
		int s = n%b;
		r=r+s*i;
		canviar_base(r, b, n/b, i*10, nombres);
	}
	return r;
}

void compara (vector <int>& xifra){
	int max=0;
	int imax=0;
	for(int i=0; i<xifra.size(); ++i){
		if (xifra[i]>max) {
			imax=i;
			max=xifra[i];
		}
	}
	cout<<imax<<" "<<max<<endl;
}

void nombre_frequent (const vector <int>& nombres, vector <int>& xifra){
	int n = nombres.size();
	for (int i = 0; i<n; ++i){
		int k = nombres[i];
		if (k==0) ++xifra[0];
		while(k>0){
			++xifra[k%10];
			k=k/10;
		}

	}
	compara(xifra);

}

int main() {

	int b,k;
	cin>>b;
	vector <int> xifra (10,0);
	vector <int> nombres;
	while (cin>>k){
		int r = 0;
		int i = canviar_base(r,b,k,1,nombres);
		nombres.push_back(i);
	}

	nombre_frequent(nombres,xifra);

}