#include <iostream>
#include <cmath>
using namespace std;

void escriu_hora(int h, int m, int s){
	
	

	cout << h << ":" << m << ":" << s << endl;
}

void llegeix_hora(int& h, int& m, int& s){

	char a;
	char c;
	int i;
	int sum=0;
	cin>>c;
	while (cin >> a and a!=c){
		if (a=='*') i = 1;
		if (a=='$') i = 0;

		h = i + sum*10;
		sum = h; 
	}
	
	sum=0;
	if (a==c){
		
		while (cin >> a and a!=c){
			if (a=='*') i = 1;
			if (a=='$') i = 0;

			m = i + sum*10;
			sum = m; 
		}
		
	}
	sum = 0;
	if (a==c){
		
		while (cin >> a and a!=c){
			if (a=='*') i = 1;
			if (a=='$') i = 0;

			s = i + sum*10;
			sum = s; 
		}
		
	}

	i = 0;
	int r1=0;
	int r2=0;
	int r3=0;
	
	while (h%10==0 and h!=0){
			h=h/10;
			++i;
			
	}
	r1 = (h%10)* pow (2,i);
	
	while (h>0){

		++i;
		r1 = r1+ (h/10)%10 * pow (2,i); 
		
		h=h/10;
		
		
	}

	i=0;
	while (m%10==0 and m!=0){
			m=m/10;
			++i;
			
	}
	r2 = (m%10)* pow (2,i);
	
	while (m>0){	
		++i;
		r2 = r2+ (m/10)%10 * pow (2,i); 
		
		m=m/10;
		
		
	}
	i=0;
	while (s%10==0 and s!=0){
			s=s/10;
			++i;
			
	}
	r3 = (s%10)* pow (2,i);
	
	while (s>0){

		++i;
		r3 = r3+ (s/10)%10 * pow (2,i); 
		
		s=s/10;
		
		
	}
	h=r1;
	m=r2;
	s=r3;

	escriu_hora (h,m,s);
	r1=0;
	r2=0;
	r3=0;
	i=0;
	sum=0;
}

int main (){
	int h,m,s;
	int i;
	cin >> i;
	while (i>0){
		llegeix_hora(h,m,s);
		--i;
	}

}