#include <iostream>
using namespace std;

bool avalua (char n){
	char c;
	int k;
	if (n=='!'){
		cin>>c;
		if (c=='1')return false;
		return true;
	}
	return false;

	if (n=='('){
		char n,m,p
		cin>>n>>m>>p;
		if (m=='*'){
			if (n==0 or m==0)


	}
	if (n=='1' or n=='0') return n-'0';
}

int main (){
	char n;
	while (cin>>n){
		cout<< avalua (n)<<endl;
	}

}
	