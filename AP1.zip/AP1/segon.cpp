#include <iostream>
using namespace std;

int main () {
	int h, m, s; 
	cin >> h >> m >> s;

	s= s+1;
	if (s == 60) {
		m = m + 1;
		s = 0;

		if (m == 60) {
			m = 0;
			h = 0;

			if (h == 24){
				h = 0;
			}
		}
	}
		
	if (h<10) {
		cout << "0";
		cout << h << ":";
	}
		else cout << h << ":";
	
	
	if (m<10) {
		cout << "0";
		cout << m << ":";}
		else cout << m << ":";
	
	if (s<10) {
		cout << "0";
		cout << s ;
	}
		else cout << s << endl;
	


}

