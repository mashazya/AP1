#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n;
    cin>>n;
    vector <int> v(1001);
    vector <int> store(n);
    for (int i = 0; i< n; ++i){
        int m;
        cin>>m;
        store[i]=m;
        ++v[m%10000];
    }
    for(int i=0; i<1001; ++i){
        if (v[i]!=0){
            cout << i+1000000000 << " : "<< v[i] << endl;
        }
    }
  
}
