#include <iostream>
#include <cmath>
using namespace std;

bool primer(int n){
	if (n==2) return true;
	if (n<2)return false;
	int x=2;
	while (x*x<=n){
		if (n%x==0) return false;
		++x;
	}
	return true;
}

int num_dig (int n){
	int i=0;
	while (n > 0) {
		n = n/10;
		i= i+1;
	}
	return i;
}

int concatenacio(int n, int m){
	int x = n*pow(10,num_dig(m));
	int k = x+m;
	return k;
}


int main (){
	int n,m;
	cin>>n;
	bool trobat = false;
	while (cin>>m and not trobat){
		int concat = concatenacio(n,m);
		if (not primer(concat)) {
			trobat = true;
			cout << concat << endl;
		}
		else n=m;
		
	}
	if (not trobat) cout << "no" << endl;

}


