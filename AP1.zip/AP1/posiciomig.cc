#include <iostream>
#include <vector>

using namespace std;

int posicio(int x, const vector <int>& v){
	int n=v.size ();
	int esq = 0;
	int dre = n-1;
	while (esq<=dre){
		int mig = (esq+dre) / 2;
		if (v[mig]) == x) return mig;
		else if (v[mig]>x) dre = mig-1;
		else esq=mig-1;
	}
	return -1;
}

int main (){
	vector <int> v = {3, 5, 5 ,8, 9, 12, 15}
	cout << posicio (9,v) << endl;

}

-_