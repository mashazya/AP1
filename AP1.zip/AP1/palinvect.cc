#include <iostream>
#include <vector>
#include <string>
using namespace std;

bool is_palindrome(const string& s){
    int n = s.size();
    int mig = n/2;
    for (int i = 0; i<mig; ++i){
        if (s[i]!=s[n-1-i]) return false;
    }
    return true;
}


int main() {
    string s;
    while(cin>>s){
        cout<< is_palindrome(s)<<endl;
    }

}


