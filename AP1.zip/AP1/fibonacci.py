from jutge import read


def fibonacci (n):
	a,b = 0,1
	for i in range (n): #range (0,n)
		a,b = b,a + b-1

	return a

def main ():
	a=read(int)

	print (fibonacci(a))

main ()

