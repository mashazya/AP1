#include <iostream>
#include <vector>
#include <string>
using namespace std;
using Matrix=vector<vector<int>>;


int main(){
	int  files, columnes;
	cin>> files >> columnes;
	Matrix M (files,vector<int>(columnes));
	for (int i=0; i<files; ++i){
		for (int j=0; j<columnes; ++j){
			cin>> M[i][j];
		}
	}
	string x;
	int n,m;
	while (cin >> x){
		if (x=="row"){
			cin>>n;
			cout << x << " " << n <<":";
			for(int j = 0; j< columnes; ++j){
				cout<< " " << M[n-1][j];
			}
			cout<< endl;
		}
		if (x=="column"){
			cin>>n;
			cout << x << " " << n <<":";
			for(int i = 0; i<files; ++i){
				cout<< " " << M[i][n-1];
			}
			cout<< endl;
		}
		if (x=="element"){
			cin>>n>>m;
			cout << x << " " << n << " "<< m <<": ";
			cout<< M[n-1][m-1] << endl;
		}
	}

}