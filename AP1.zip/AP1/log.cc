#include <iostream>
#include <cmath>
using namespace std;

int main (){
	int a;
	int b;

	while (cin >> a >> b){
		
		cout << int (log10(b)/log10(a)) << endl;
	}
}