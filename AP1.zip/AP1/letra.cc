#include <iostream>
using namespace std;

void letra (char c){
	int i;
	if (c=='a')i=1;
	if (c=='b')i=2;
	if (c=='c')i=3;
	if (c=='d')i=4;
	if (c=='e')i=5;
	if (c=='f')i=6;
	if (c=='g')i=7;
	if (c=='h')i=8;
	if (c=='i')i=9;
	if (c=='j')i=10;

	int b=i;
	char a;

	while (i>1){

		cout << c;

		if (i==1) a= 'a';
		if (i==2) a= 'b';
		if (i==3) a= 'c';
		if (i==4) a= 'd';
		if (i==5) a= 'e';
		if (i==6) a= 'f';
		if (i==7) a= 'g';
		if (i==8) a= 'h';
		if (i==9) a= 'e';
		if (i==10) a= 'j';
		cout<<a;
		--i;
	}

	cout <<  endl;

}
int main (){
	char c;
	cin >>  c;
	letra(c);
}