#include <iostream>
#include <cassert>
using namespace std;

bool primer(int n){
	if (n==2) return true;
	if (n<2)return false;
	int x=2;
	while (x*x<=n){
		if (n%x==0) return false;
		++x;
	}
	if (n>=2)return true;
	return false;
}


int sum_of_digits(int x){
	int sum=0;
	while (x>=1){
		sum= x%10+sum;
		x=x/10;
		
	}

	return sum;
}


bool is_perfect_prime(int n){
	if (n>9){
		return (is_perfect_prime(sum_of_digits(n)) and primer(n));
	}
	else return(n==2 or n==3 or n==5 or n==7);
	
}



int main (){
	int n;
	cin >> n;
	cout<< is_perfect_prime(n) <<endl;
	
}