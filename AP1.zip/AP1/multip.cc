#include <iostream>
using namespace std;
int main () {
	
	int n;
	cin >> n;

	int i = 1;
	int x;
	

	while (i<=10) {
	cout << n << "*" << i << " " << "=" << " ";
	x = n * i;
	i = i + 1;
	cout << x << endl;
	}


}