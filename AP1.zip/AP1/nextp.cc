#include <iostream>
using namespace std;

bool es_primer(int n) {
    if (n <= 1) return false;
    int i = 2;
    while (i*i <= n) {  // equival a i <= arrel(n)
        if (n % i == 0) return false;
        ++i;
    }
    return true;
}

int main () {
	int a;
	while(cin >>a and es_primer(a)==true){
		++a;
		while (es_primer(a)!=true){
			++a;
		}
		if (es_primer(a)==true) cout << a << endl;
	}

}