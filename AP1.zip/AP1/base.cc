#include <iostream>
#include <cmath>
using namespace std;

 bool three_equal_consecutive_digits(int n,int b){
	int r;
	int sum =0;
	int x=1;
	int i=0;
	int k;
	int m;
	if (n==0) return false;
	while (n>0){
		r=n%b;
		sum = sum+r*x;
		n=n/b;
		x=x*10;
		if (sum>100){
			k=(sum%100)/10;
			m = sum%10;
			if (m==k){
				++i;
				sum= sum/10;
			}
			if (m!=k){
				i=0;
				sum= sum/10;
				x=x/10;
			}
			if (i==2){
				
				return true;
			}
		}

	}
	if (n==0 and sum>0){
		while (sum>0){
			k=(sum%100)/10;
			m = sum%10;
			if (m==k){
				++i;
				sum= sum/10;
			}
			if (m!=k){
				i=0;
				sum= sum/10;
				x=x/10;
			}
			if (i==2){
				return true;
			}
		}
	}
	return false;
}
int main (){
	int n,b;
	cin>>n>>b;
	three_equal_consecutive_digits(n,b);
	
}


