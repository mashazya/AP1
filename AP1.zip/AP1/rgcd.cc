#include <iostream>
#include <algorithm>
using namespace std;

int gcd(int a, int b){
	if (a==0) return b;
	if (b==0) return a;

	if (b>a) swap(b,a);
	int r=a%b;
	if (r>0){
		return gcd(b,r);
	}
	return b;

	
}

int main (){
	int a,b;
	while (cin>>a>>b)
	cout << gcd (a,b) << endl;


}