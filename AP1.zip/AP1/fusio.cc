#include <iostream>
#include <vector>
using namespace std;

void merge(vector<double>&v, int esq,int mig,int dre){

  vector<double> aux;
  int i=esq;
  int j=mig+1;
  while (i<=mig and j<=dre){

    if (v[i]<=v[j]){
      aux.push_back(v[i]);
      ++i;
    }
    else {
      aux.push_back(v[j]);
      ++j;
    }
  }
  while (i<=mig) {
     aux.push_back(v[i]);
     ++i;
   }

   while (j<=dre){
    aux.push_back(v[j]);
    ++j;
   }
  
  for (int k = 0; k < dre - esq + 1; ++k) {
        v[k + esq] = aux[k];
    }
}

void mergesort_recursiu(vector<double>& v, int esq, int dre){
  if (dre-esq>=1){
    int mig= (esq+dre)/2;
    mergesort_recursiu(v,esq,mig);
    mergesort_recursiu(v,mig+1,dre);
    merge(v,esq,mig,dre);
  }

}

void mergesort(vector<double>& v){
  mergesort_recursiu(v,0,v.size()-1);
}



int main() {
    int n;
    while (cin >> n) {
        vector<double> v(n);
        for (int i=0; i<n; ++i) {
            cin >> v[i];
        }
        mergesort(v);
        for (int i=0; i<n; ++i) {
            cout << " " << v[i];
        }
        cout << endl;
    }
}


