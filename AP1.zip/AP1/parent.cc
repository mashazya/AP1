#include <iostream>

using namespace std;

int main (){
	char c;
	int a=0;
	int b=0;
	while (cin >> c and a>=b){
		if (c=='(') ++a;
		else ++b;
	
	}
	
	if (a==b) cout<< "yes"<<endl;
	else cout<<"no"<<endl;
	
	
	
	
}