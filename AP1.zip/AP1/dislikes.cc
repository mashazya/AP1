#include <vector>
#include <iostream>
#include <string>
using namespace std;
using Matrix = vector<vector<int>>;
using vect = vector<int>;

/*int suma(int n, const Matrix& M, const vector <int>& v){
	int sum = 0;
	for  (int i=0; i<n-1; ++i){
		sum = sum+ M[v[i]][v[i+1]];
	}
	return sum;

}
*/

void  escriu (vector <int>& aux,const vector <string>& names, int& minim){
	int n = aux.size();
	cout<<minim<<endl;
	int  j=n;
	for (int i = 0; i<n; ++i){
		cout<< names[aux[i]];
		--j;
		if (j>0) cout <<" ";

	}
	cout<<endl;
}

void genera (int i, vector <int>& v, int n, vector <bool>& usat, const vector <string>& names,Matrix& M, int& minim,vector <int>& aux, int suma){
	if (suma>=minim and minim !=0)return;
	if (i==n){
		minim=suma;
		aux=v;
		return;
	}
	else{
		for (int j = 1; j<n; ++j){
				if (not usat[j]){
					v[i]=j;
					usat[j]=true;
					genera(i+1, v, n,usat,names,M,minim,aux,suma+M[v[i]][v[i-1]]);
					usat[j]=false;
			}
		}
	}
}


int main (){
	int n;
	while(cin>>n){
		vector <string> names(n);
		for (int i = 0; i<n; ++i){
			cin>> names[i];
		}
		Matrix M (n, vector <int> (n));
		for (int i = 0; i<n; ++i){
			for (int j = 0; j<n; ++j){
				cin>> M[i][j];
			}
		}
		vector <bool> usat (n,false);
		vector <int> v(n);
		vector <int> aux(n);
		int minim=0;
		int suma=0;
		genera(1,v,n,usat,names,M,minim,aux,suma);
		escriu(aux,names,minim);
	}

}