#include <iostream>
#include <vector>
using namespace std;


vector<int> ex_union(const vector<int>& v1, const vector<int>& v2){
	int n = v1.size();
	int m = v2. size();
	int i = 0, j=0;
	vector<int> aux;
	while(i<n and j<m){
		if (v1[i]<v2[j]){
			aux.push_back(v1[i]);
			int s=v1[i];
			while(i<n and v1[i]==s) ++i;
		}
		else if (v1[i]>v2[j]){
			aux.push_back(v2[j]);
			int s=v2[j];
			while(j<m and v2[j]==s) ++j;
		}
		else {
			int s=v1[i];
			while(i<n and v1[i]==s) ++i;
			s=v2[j];
			while(j<m and v2[j]==s) ++j;
		}
	}


	if  (j==m and i<n){
		while(i<n){
			aux.push_back(v1[i]);
			int s=v1[i];
			while(i<n and v1[i]==s) ++i;
		}
	}
	if  (i==n and j<m){
		while(j<m){
			aux.push_back(v2[j]);
			int s=v2[j];
			while(j<m and v2[j]==s) ++j;
		}
	}
	return aux;

}


int main (){
	int n;
	cin>> n;
	vector <int> v1 (n);
	for (int i = 0; i < n; ++i) cin >> v1[i];
	int m;
	cin>> m;
	vector<int> v2 (m);
	for (int i = 0; i < m; ++i) cin >> v2[i];
	vector<int>unio=ex_union(v1,v2);

	if (unio.size()>0) {
      for (int i=0; i<unio.size(); ++i){
        cout<<unio[i]<<" ";
      }
    }
    else cout<< "0"<<endl;
    cout<<endl;



}