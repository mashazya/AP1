#include <iostream>
using namespace std;


char rectangle (char c){
 	bool gs = false;
 	bool is = false;
	
	while (cin >> c and not gs and not is){
		if (c=='g'){
			gs = true;
		}
		if (c=='i') {
			is = true;
		}

	}

if (gs) {
	cin >> c;
	return true;
}

int n=3;

if (is) {
	while (n>0){
		cin >> c;
		--n;
	}
	
}

return false;
}

int main (){
	int x;
	cin >> x;

	cout.setf (ios::fixed);
	cout.precision(6);
	char c;
	double l;
	double w;
	double r;
	double pi = 3.14159265358979323846;

	while (x>0){

		if (rectangle (c)) {

			cin >> l >> w;
			cout << l*w << endl;

		}

		else {
			cin >> r;
			cout << pi*r*r << endl;
		}
	--x;

	}
}

	// rectangle
	// circle