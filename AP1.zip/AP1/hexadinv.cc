#include <iostream>
using namespace std;
int main() {


int x;
cin >> x;
int n = x;
if (x<16){
	if (x>=10) {
		if (x == 0) cout << "0";
		if (x == 10) cout << "A";
		if (x == 11) cout << "B";
		if (x == 12) cout << "C";
		if (x == 13) cout << "D";
		if (x == 14) cout << "E";
		if (x == 15) cout << "F";

	}
	if (x<10) cout << x;
}

else{

	while (n>=16){
	x = n % 16;
		
	if (x>=10) {
		if (x == 10) cout << "A";
		if (x == 11) cout << "B";
		if (x == 12) cout << "C";
		if (x == 13) cout << "D";
		if (x == 14) cout << "E";
		if (x == 15) cout << "F";
	}
	else cout << x;


	n = n/16;
	
	}

	if (n>0) cout << n;

}

	cout<< endl;
}