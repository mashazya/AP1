#include <iostream>
using namespace std;

int gcd2 (int a, int b) {
	if (b==0) return a;
	return gcd2(b, a%b);
}

int gcd3 (int a, int b, int c){
	if (c==0) return a;
	return gcd2(c, gcd2(b, a%b)%c);

}

int gcd4 (int a, int b, int c, int d) {
	if (d==0) return a;
	return gcd2 (d, gcd2(c, gcd2(b, a%b)%c)%d);

}

int main () {
	int a, b, c, d;
	cin >> a >> b >> c >> d;
	cout << gcd4(a,b,c,d) << endl;

}