#include <iostream>
using namespace std;

bool is_palindromic (int n){
	int x=n;
	int i=0;
	while (x > 0){//456
		x=x/10;
		++i;//3
	}

	x=n;
	int m=0;
	int k;
	int l;
	int j=i;
	int h = 1;

	while (j>0){
	i=h; 
	h=h*10;
	--j;
	}


	while (x>0){
		
		k=(x%10);
		x=x/10;
		m=(k*i)+m;
		l=m;
		i=i/10;

		
	}
	
	if (n==m) return true;
	return false;

}

int main () {
	int n;
	cin >> n;
	cout << is_palindromic (n) << endl;
}