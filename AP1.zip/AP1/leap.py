from jutge import read
def main():

	a = read (int)
	x = a % 4
	r = a % 100
	c = (a//100)%4
	if x <= 0 and r>0: 
		print("YES")
	
	else:
		if r <= 0 and c <= 0:
			print("YES")
		else :
			print("NO")

main ()
