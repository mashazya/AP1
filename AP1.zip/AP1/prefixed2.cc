#include <iostream>
#include <vector>
using namespace std;

int max3 (int a, int b, int c){
	int max = a;
	if (b>max) max = b;
	if (c>max) max = c;
	return max;
}

int prefixed (){
	char c;
	cin >> c;//a cada crida recursiva llegin un caracter
	if (c >= '0' and c <= '9') return c-'0';//si llegim un numero el retornem
	else {
		if (c=='+') return prefixed() + prefixed ();
		else if(c=='-') return prefixed()*(-1);
		else if (c=='m') return max3(prefixed(),prefixed(),prefixed());
	}
}

int main(){
	int n = prefixed ();
	cout<< n <<endl;
}