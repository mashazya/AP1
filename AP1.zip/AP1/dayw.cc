#include <iostream>
#include <string>
using namespace std;

string day_of_the_week (int d, int m, int a){
	

		m=m-2;


	if (m<=0){
		m = m+12;//
	
		a = a-1;//
		

	}

	int c = a/100;//
	
	int y = a%100;//

	int b = y/4;
	
	int n= c/4;

	int l = 2*c;
	double k =2.6 * m;

	int f = int(k - 0.2) + d + y + b + n - l;
	
	if (f<0){

		int t  = -1*f;

	 	f=7-t%7;//
	}
	//4 13
	else f=f%7;
	if (f>=7)f=f%7;

	

	if (f==0) return "Sunday";
	if (f==1) return "Monday";
	if (f==2) return "Tuesday";
	if (f==3) return "Wednesday";
	if (f==4) return "Thursday";
	if (f==5) return "Friday";
	if (f==6) return "Saturday";
return "lelo";
}

int main () {
	int d,m,y;
	cin >> d >> m >> y;
	cout << day_of_the_week (d,m,y) << endl;

}