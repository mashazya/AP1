#include <iostream>
#include <vector>
#include <string>
using namespace std;
using Matrix=vector<vector<char>>;

Matrix creus (Matrix& M,int n){
	int m = n;

	while(m>0){
		for (int j=n-m;  j<m; ++j){
			int i = m-1;
			M[i][j]='X';
		}
		--m;
		for (int i = n-m-1; i<m; ++i){
			int j = m;
			M[i][j]='X';
		}
		--m;
	}

	int t = n-1;
	while(t>0){
		for (int j = n-t; j<t; ++j){
			int i = n-t-1;
			M[i][j]='X';
		}
		--t;
		for (int i = n-t-1; i<t; ++i){
			int j = n-t-1;
			M[i][j]='X';
		}
		--t;
	}

	return M;

}

int main(){
	int n;
	while(cin>>n and n!=0){
		int files=n;
		int columnes=n;
		Matrix M (files,vector<char>(columnes));
		for (int i=0; i<n; ++i){
			for (int j=0; j<n; ++j){
				M[i][j]='.';
			}
		}
		M=creus(M,n);
		

		for (int i=0; i<files; ++i){
			for (int j=0; j<columnes; ++j){
				cout << M[i][j];
			}
			cout<<endl;
		}
		cout<<endl;
	}
	
}