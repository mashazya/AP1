#include <iostream>
using namespace std;


int maxim2(int x,int y){
	if (x>y) return x; // si no es cierto el programa acaba y va a la siguiente orden
	return y;

}


int maxim3 (int x, int y, int z){
	return maxim2(x, maxim2(y,z))
}
	int main() {
		

	}
