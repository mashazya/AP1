#include <iostream>
using namespace std;
int main() {

int a;
cin >> a;

int x = a%4;
int r = a % 100;
int c = (a/100)%4;
	if (x <= 0 and r>0) {
		cout << "YES" << endl;
	}

	else 

		if (r <= 0 and c <= 0) {
			cout << "YES" << endl;

		}

		else 
			cout << "NO" << endl;

	

}