#include <iostream>
#include <cmath>

using namespace std;


int main () {
	cout.setf (ios::fixed);
	cout.precision(6);

	double x;
	double c;
	double s;
	double pi = 3.14159265358979323846;
	
	while (cin>>x){
		s = sin (x*pi/180);
		c = cos (x*pi/180);
		cout << s << " " << c << endl;


	}


}