#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void insert(vector<double>& v, int n){
    int j = n-1;
    while (j>=0 and v[j]>v[j+1]){
        swap (v[j],v[j+1]);
        --j;
    }

}

void insertion_sort(vector<double>& v){
    int n = v.size();
     for (int i = 1; i<n; ++i){
        insert(v,i);
    }
}


int main() {
    cout.setf(ios::fixed, ios::floatfield);
    cout.precision(4);
    int n;
    while (cin >> n) {
        vector<double> V(n);
        for (int i=0; i<n; ++i) {
            cin >> V[i];
        }
        insertion_sort(V);
        for (int i=0; i<n; ++i) {
            cout << " " << V[i];
        }
        cout << endl;
    }
}

