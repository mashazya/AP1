#include <iostream>
#include <string>
using namespace std;


int main (){

int a;

string (i) = "I";
string (v) = "V";
string (x)= "X";
string (l) = "L";
string (c) = "C";
string (m) = "M";
string (d) = "D";



while (cin >> a and a!=0){

	int p = a;
	cout << a << " = ";
	if (a>1000 and a <4000 ){
		p=p/1000;	
		while (p>0){
			cout << m;
			--p;

		}
	a=a%1000;	

	}
	
	if (a==1000) cout << m;



int k = a;
	if (a>100 and a <= 999){
		k=k/100;
			
			if (k<4){
				while (k>0){
					cout << c;
					--k;
				}	
			}
			if (k==4) {
			
			cout << c << d;
			}

			if (k>4 and k<9) {
				cout << d;
				while (k>5){
					cout << c;
					--k;
				}
			}
			if (k==9) cout << c << m;
	a=a%100;	

	}

	int r = a;

	if (a==99) cout << x << c << i << x;
	if (a==100) cout << c;

	if (a>10 and a<99){
		r=r/10;

		//falta per mes gran que 40
			
			if (r<4){
				while (r>0){
					cout << x;
					--r;
				}	
			}
			if (r==4) {
			
			cout << x<< l;
			}

			if (r>4 and r<9) {
				cout << l;
				while (r>5){
					cout << x;
					--r;
				}
			}
			if (r==9) cout << x << c;
	
	a=a%10;
	}
	if (a==9) cout << i << x;
	if (a==10) cout << x;

	if (a<9){
		if (a<4) {
			while (a>0){
				cout << i;
				--a;
			}	
		}
	
		if (a==4) {
			
			cout << i << v;
		}

		if (a>4) {
			cout << v;
			while (a>5){
				cout << i;
				--a;
			}
		}
	}
	
	cout << endl;

}
}