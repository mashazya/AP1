#include <iostream>
using namespace std;
int main () {
	
	int x,y;
	cin >> x >> y;


	if (x<=y){

		while (x<y) {
		cout << x << ",";
		x = x+1;
		}

		cout << x;

	}

cout << endl;




}