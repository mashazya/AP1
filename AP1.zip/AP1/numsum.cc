#include <iostream>
using namespace std;

void count_and_add(int& num, int& sum){
	int a;
	num = 0;
	sum = 0;
	while (cin >>a){
		++num; 
		sum = sum + a;
	}
}

int main () {
	int sum;
	int num;
	count_and_add (num,sum);
}