#include <iostream>
#include <vector>
using namespace std;


vector<int> ex_union(const vector<int>& v1, const vector<int>& v2){
	int n = v1.size();
	int m = v2.size();
	int i=0;
	int j =0;
	vector<int> aux;

	if (v1[i]<=v2[m-1]){
		aux.push_back(v1[0]);
		++i;
		while(i<n){
			if (v1[i]!=v1[i-1]) aux.push_back(v1[i]);
			++i;
		}
		while (j<m){
			if (v1[n-1]!=v2[0]) aux.push_back(v2[j]);
			++j;
		}
	}
	else {
		if (v1[i]!=v2[j]) 
		if (v1[i]<v2[j]){
			while (v1[i]!=v1[i-1] and v1[i]<v2[j])aux.push_back(v1[i]);
		}

	}
	return aux;
}

int main() {
  int n1;
  while (cin >> n1) {
    vector<int> v1(n1);
    for (int i = 0; i < n1; ++i) cin >> v1[i];
    int n2;
    cin >> n2;
    vector<int> v2(n2);
    for (int i = 0; i < n2; ++i) cin >> v2[i];
    vector<int> res = ex_union(v1, v2);

    if (res.size()>0) {
      for (int i=0; i<res.size(); ++i){
        cout<<res[i]<<" ";
      }
    }
    else cout<< "0"<<endl;
    cout<<endl;
  }

}
