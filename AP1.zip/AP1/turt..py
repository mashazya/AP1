import jutge
import turtle

def patro (llargada):

	if n==0:
		turtle.forward(llargada*3)
	else:
		patro(n-1,llargada/3.0)
		turtle.left(60)
		patro(n-1,llargada/3.0)
		turtle.right(120)
		patro(n-1,llargada/3.0)
		turtle.left(60)


	def main ():
		n=jutge.read(int)
		patro(n,100)
		jutge.read(chr)

	main()