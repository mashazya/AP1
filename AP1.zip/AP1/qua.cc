#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<int>>;

void genera (int n, Matrix& M){
	
	for (int i=0; i<n; ++i){
		int c=1;
		for (int j=0; j<n; ++j){
			if (j<=i) M[i][j]=(n-i-c)%10;
			else {
				M[i][j]=(n-(i+1+c))%10;
				++c;
			}
		}
	}
	
}

int main (){
	int n;
	cin>>n;
	Matrix M (n,vector<int>(n));
	genera(n, M);

	for(int i=0; i<n; ++i){
		for(int j=0; j<n; ++j){
			cout<< M[i][j];
		}
		cout<<endl;
	}
}