#include <iostream>
using namespace std;
int main() {
int a, b , c, d;
cin >> a >> b >> c >> d;



	// [1,2] [1,2]
	if (a==c and b==d)
	cout << "=" << " , ";
	else {

		//[1,2] [0,2] // 1,2 1,3 
		if ((c<=a and d>b) or (c<a and d>=b)) 
		cout << "1" << " , ";
		else {

			// [0,3] [0,2] // 0,3 1,3 
			if ((a<=c and b>d) or (a<c and b>=d))
			cout << "2" << " , ";
			else {

				// [1,2] [3,4] // [2,3][0,0] // 2,3 1,2 
				if ((b<=c) or (d<=a))
				cout << "?" << " , ";
				else cout << "?" << " , ";
			}
		}
	}


	int x, y;

	cout << "[" ;

	if ( b< c) cout << "]" << endl;
	else {



		if (a >= c and d>=a){
		x = a;}

		if (a<c and b>= c){
		x = c;}

		// 10 18 18 30
		if (b>=d ){
			if (b==c)
			y = b;
			else
			y = d;
		}

		if (b<d){
			if (b==c)
			y = b;
			else
		y = b;
		}


		if ((a >= c and a<= d) or (c>=a and c <=b)) cout << x << "," << y;

		cout << "]" << endl;

	}


}
