#include <iostream>
using namespace std;
int main () {
	int i = 1;
	while (i <= 1000) {
	cout << i << endl;
	i = i+1;
	}
cout << "ja esta!" << i << endl;
}