#include <iostream>
using namespace std;

void start (int c){
	cout << " ";
	while (c>0){
		cout << "_";
		if (c>1) cout << "   ";
		--c;
	}
	cout << endl;
}

void col (int f){
	int n = f;
	while (f>0){
		cout << "/ " << "\\";
		if (f>1) cout << "_";
		--f;
	}
	f=n;
	cout << endl;

	while (f>0){
		cout << "\\" << "_" << "/";
		if (f>1) cout << " ";
		--f;
	}



}

void pinta_rusc(int f, int c){

	start (c);
	while (f>0){
		col (c);
		--f;
		if (f!=0) cout << endl;
	}

}

int main (){

	int f,c;
	int i = 0;
	while (cin >> f >> c){
		if (i!=0) cout << endl<<endl;
		pinta_rusc (f,c);
		++i;
	}
	cout << endl;
}