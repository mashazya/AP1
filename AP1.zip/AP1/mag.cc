#include <iostream>
using namespace std;

int main (){

	int y;

	while (cin >> y){
		cout << (y-165)/100 << endl;
	}
}