#include <iostream>
using namespace std;
int main() {


int x;
cin >> x;
int n = 1;
int i = 0;




while (n > 0 and x>0) {
cout << "*";
n = n-1;

	if (n == 0) {
		cout << endl;
		i=i+1;
		n = i + 1;
		x=x-1;

	}
}

}


