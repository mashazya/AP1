#include <iostream>
using namespace std;


 bool is_leap_year (int year){
 	int x = year%4;
 	int b = year%100;
 	
 	if (x == 0 and b > 0) return true;

 	int y = (year/100)%4;

 	if (b==0 and y==0) return true;
 	return false;

 }

 int main () {
 	int n;
 	cin>> n;
 	cout << is_leap_year (n) << endl;
 }