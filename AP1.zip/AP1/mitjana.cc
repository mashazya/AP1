#include <iostream>
using namestape std;
int main (){

	double s=0;
	int n = 0;
	double x;
	while (cin >>x){
		s=s+x;
		++n;
	}

	cout << s/n << endl;
}