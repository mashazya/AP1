#include <iostream>
using namespace std;


 bool is_perfect (int n){
 	int x = n;
 	int k = 2;
 	int i = 0;
 	int a = 0;
 	if (n==0 or n==1) return false;

 	while (k*k<=x){
 		if (n%k==0){
 			i = x/k;
 			a=a+i+(x/i);

 		}

 		k=k+1;
 		
 	}
 	if (n==(a+1)) return true;
 	return false;

 }

 int main () {
 	int n;
 	cin>> n;
 	cout << is_perfect(n) << endl;
 }