#include <vector>
#include <iostream>
using namespace std;

void escriu (const vector <int>&v){
	int i = 0;
	for (int x: v){
		if (i>0) cout<< " ";
		cout << x;
		++i;
	} 
	cout<<endl;
}

void genera (vector<int>&v, int i){
	int n =v.size();
	if (i==n){
		escriu(v);
	}
	else{
		v[i]=0;
		genera(v,i+1);
		v[i]=1;
		genera(v,i+1);
	}


}

int main (){
	int n;
	cin>>n;
	vector<int> v(n);

	genera(v, 0);
}