import jutge

print ("hola")