from jutge import read
x = read(int)

c = 1
while c <= 10:
	r = c * x
	print (x,'*',c, ' ', '=', ' ',r, sep='')
	c = c + 1
