#include <iostream>
using namespace std;
int main() {


int x;
cin >> x;
int n = x;
int i = 0;




while (n > 0 and i<x) {
cout << "#";
n= n-1;

	if (n == 0) {
		n = x;
		i = i +1;
		cout << endl;
	}
}

}