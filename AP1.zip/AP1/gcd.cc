#include <iostream>
using namespace std;
int main() {

int x;
int y;
cin >> x >> y;
int a;
int i=x%y;



cout << "The gcd of " << x << " and " << y << " is ";
if (i==0)

		cout << y << "." << endl;
// x=16104 y=3216

while (i>0){
	
	a=y; //a=24
	i=x%y; // i=0
	y=i; //y=0
	x=a; //x=24
	if (i==0)

		cout << a << "." << endl;

	
}



}