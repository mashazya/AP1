#include <iostream>
#include <iomanip>
using namespace std;



int main (){

cout.setf(ios::fixed);
cout.precision(2);

double n;
int i = 0;
double sum = 0;

	while (cin>>n){
		sum = sum+n;
		++i;

 	}

 cout << sum/i << endl;

}