from jutge import read
def product_digits (n, p):
	if n//10 > 0:
		print("The product of the digits of", n, "is ", end='')
		while n>0:
			p=p*(n%10)
			n=n//10

		print(p, '.',sep='')
		product_digits(p,1)
	


def main():
	n = (read (int))
	while n is not None:
		if n>=10:
			product_digits(n, 1)
		else:
			print("The product of the digits of ", n , " is ", n,'.',sep='')
		print('----------')
		n = (read (int))

main()
	