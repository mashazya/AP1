#include <iostream>
#include <vector>
#include <string>
using namespace std;

void invertir (string v){
    int n = v.size()-1;
    for (int i = n; i>=0; --i){
        cout<<v[i];
    }
    cout<<endl;

}


int main() {
    string v;
    int n;
    cin>>n;
    vector <string> paraules(n);
    for (int i = 0; i<n;++i){ 
        cin >> v;
        paraules[i]=v;
    }
    for (int i=n-1; i>=0; --i){
        invertir (paraules [i]);
    }
    
}


