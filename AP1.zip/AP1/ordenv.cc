#include <iostream>
#include <vector>
#include <assert>
using namespace std;


void fusio (vector<double>& v, int esq,int mig,int dre){
	vector<double> aux;
	int i = esq;
	int j = mig +1;
	while (i<=mig and j<= dre){
		if (v[i] <=v[j]){
			aux.push_back(v[i]);
			++i;
		}
		else {
			aux.push_back(v[j]);
			++j;
		}
		if (i <=mig){
			aux.push_back(v[i]);
			++i;
		}
		if (j <=dre){
			aux.push_back(v[j]);
			++j;
		}
		for (int k = 0; k< dre-esq+1; ++k) v[k+esq] = aux [k];
	}
}

void ordenacio_per_fusio_rec (vector<double>& v, int esq,int dre){
	if (dre-esq>=1){
		int mig = (esq + dre)/2;
		ordenacio_per_fusio_rec(v,esq,mig);
		ordenacio_per_fusio_rec(v,mig+1,dre);
		fusio (v,esq,mig,dre);

	}
}

void ordenacio_per_fusio (){//un vector es divideix entre dos
//parts i s'ordena cada part per separat
//l'alrogitme retorna la unio de les dues parts ordenada
	ordenacio_per_fusio_rec (v,0,v.size()-1);



}

int main (){
	int n;
	cin >> n;
	vector <double> v(n);
	for (double& x: v) x= rand()/double (RAND_MAX);
	ordenacio_per_fusio(v);
	//sort (v.begin(),v.end())
	for (int i = 0; i<n-1;++i){//comprova si esta be posat
		assert (v[i]<= v[i+1]);
	}
}