// programa que comprova si les xifres de 3 en 3 cumpleixen 
// la propietat de les ternes pitagoriques


#include <iostream>
using namestape std;

bool es_terna_pitagorica (int a, int b, int c){
  return sqr (a) + sqr(b) == sqr (c);

}

int main () {
	int r = 0;
	int a, b,c;
	if (cin >> a>>b) {
		while (cin >>c){
			if (es_terna_pitagorica(a,b,c)) ++r;
			a=b;// moure una xifra
			b=c;
		}

	}
cout << r << endl;


}