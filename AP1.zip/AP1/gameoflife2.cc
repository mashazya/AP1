#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<char>>;

void escriu (vector<Matrix> cicle,int i, int n, int m){
	for (int k = i; k<cicle.size()-1; ++k){
		for (int p=1; p<=n; ++p){
			for(int j=1; j<=m; ++j){
				cout<<cicle[k][p][j];
			}
			cout<<endl;
		}
		cout<<endl;
	}

}


int comprova_vei(Matrix& M, int i, int j, int n, int m){
	int B=0;
		if (M[i-1][j-1]=='B')++B;
		if (M[i-1][j]=='B')++B;
		if (M[i-1][j+1]=='B')++B;
		if (M[i][j-1]=='B')++B;
		if (M[i][j+1]=='B')++B;
		if (M[i+1][j-1]=='B')++B;
		if (M[i+1][j]=='B') ++B;
		if (M[i+1][j+1]=='B') ++B;

	if (B>3) return 4;
	return B;
}


Matrix game_of_life (int n, int m, Matrix& M){
	Matrix T (n+2, vector <char> (m+2,'.'));
	for (int i = 1; i<=n; ++i){
		for (int j=1; j<=m; ++j){
			int vei = comprova_vei(M, i, j, n, m);
			
			if (M[i][j]=='.'){
				if (vei == 3) T[i][j]='B';
			}
			if (M[i][j]=='B'){
				if (vei == 3 or vei == 2) T[i][j]='B';
			}
		}

	}
	return T;

}

bool hi_ha_cicle (vector <Matrix>& cicle, int& start){
	
		int n = cicle.size();
		Matrix last = cicle [n-1];
		if (cicle[0]==last and n>1) {
			start=0;
			return true;
		}
		for (int i= 0; i<n-1; ++i){
			if (cicle[i]==last){
				start = i;
				return true;
			}
		}
	

	return false;

}
// 7 8 9 10 11
// 1 3 5 5 6

int main (){
	int n,m;
	cin>>n>>m;
	Matrix M (n+2, vector<char>(m+2));
	for (int i= 1; i<=n; ++i){
		for (int j=1; j<=m; ++j){
			cin>> M[i][j];
		}
	}
	vector<Matrix> cicle;
	cicle.push_back(M);
	int i=0;
	while (not hi_ha_cicle(cicle,i)){
		M=game_of_life(n,m, M);
		cicle.push_back(M);

	}


	if (hi_ha_cicle(cicle,i)){
		escriu(cicle,i,n,m);

	}




	
	
}

