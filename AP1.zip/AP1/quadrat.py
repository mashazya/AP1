from jutge import read

def quadrat (n):
	for i in range (n):
		k=i+1
		for j in range (n):
			if j<=i: print((n-k)%10,end='')
			else: 
				k=k+1
				print ((n-k)%10,end='')

		print('')

def main ():
	n=read(int)
	while n is not None:
		quadrat(n)
		n=read(int)
		if n is not None:
			print('')
		
main()