#include <iostream>
using namespace std;


void recursiu (char n){
	int i = n - 'a';//0
	while (i>0){
		--i;//0
		cout << n;//cb
		recursiu(n-1);
	}
	cout<<n;
}
int main (){
	char n;
	cin >> n;
	recursiu(n);
	cout<<endl;
}


