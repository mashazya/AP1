#include <iostream>
#include <vector>
using namespace std;
//els numeros estan ordenats de gran a petit
//el problema esta si un numero mes petit es troba mes a la esquerra
//que un mes gran(IV)>> I<V


int traduccio (char c){
	if (c=='M') return 1000;
	if (c=='D') return 500;
	if (c=='C') return 100;
	if (c=='L') return 50;
	if (c=='X') return 10;
	if (c=='V') return 5;
	if (c=='I') return 1;
	return 0;

}

int main(){
	string s;
	while (cin>>s){
		int sum=0;
		int num1=0, num2=0;

		//recorrem el string sencer

		int n = s.size();
		for (int i=0; i<n-1; ++i){//n-1pq tenim el punt al final
			num1=num2;
			num2=traduccio(s[i]);

			if (num1<=num2){
				sum=sum+num2- 2 * num1;
			}
			else sum=sum+num2;
			cout<<s[i];
		}
		cout<< " = "<<sum<<endl;

	}

}