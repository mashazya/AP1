#include <iostream>
using namespace std;


int mcd (int a, int b){
	int aux;
	while (a%b!=0){
		aux=b;
		b=a%b;
		a=aux;

	}
	return b;
}

void read_rational(int& num, int& den){
	char c;
	cin >> num;
	cin>> c;
	if (c=='/') cin >> den;
	int q = mcd (num,den);
	num = num/q;
	den = den/ q;
	
}

int main() {
    int num, den;
    read_rational(num, den);
    cout << num << ' ' << den << endl;
}
