#include <iostream>
#include <cassert>
using namespace std;


int sum_of_digits(int x){
	int sum;

	if (x>0){
		return sum= x%10 +sum_of_digits(x/10);
	}
	return false;
}

 bool is_multiple_3(int n){

 	if (n==0)return false;

 	if (sum_of_digits(n)%3==0)return true;
 	return false;
 	
 }

int main (){
	int n;
	cin >> n;
	cout<< is_multiple_3(n) <<endl;
	
}