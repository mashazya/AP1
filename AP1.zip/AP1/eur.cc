#include <iostream>
using namespace std;

int main() {

    
    int e, c;

    cin >> e >> c; 
      
     int a = e / 500;
     int b = (e % 500)/200;
     int x = ((e % 500) % 200) / 100;
     int d = (((e % 500) % 200) % 100) / 50;
     int z = ((((e % 500) % 200) % 100) % 50) /20;
     int f = (((((e % 500) % 200) % 100) % 50) % 20)/10;
     int g = ((((((e % 500) % 200) % 100) % 50) % 20) %10) / 5;
     int h = (((((((e % 500) % 200) % 100) % 50) %20) % 10) % 5) / 2;
     int i = ((((((((e % 500) % 200) % 100) % 50) %20) % 10) % 5) % 2);

     int j = c / 50;
     int k = (c % 50)/20;
     int l = ((c % 50)%20)/10;
     int m = (((c % 50)%20)%10)/5; 
     int n = ((((c % 50)%20)%10)%5)/2; 
     int o = ((((c % 50)%20)%10)%5)%2; 

	
	cout << "Banknotes of 500 euros: " << a << endl;
	cout << "Banknotes of 200 euros: " << b << endl;
	cout << "Banknotes of 100 euros: " << x << endl;
	cout << "Banknotes of 50 euros: " << d << endl;
	cout << "Banknotes of 20 euros: " << z << endl;
	cout << "Banknotes of 10 euros: " << f << endl;
	cout << "Banknotes of 5 euros: " << g << endl;
	cout << "Coins of 2 euros: " << h << endl;
	cout << "Coins of 1 euro: " << i << endl;

	cout << "Coins of 50 cents: " << j << endl;
	cout << "Coins of 20 cents: " << k << endl;
	cout << "Coins of 10 cents: " << l << endl;
	cout << "Coins of 5 cents: " << m << endl;
	cout << "Coins of 2 cents: " << n << endl;
	cout << "Coins of 1 cent: " << o << endl;
	
}

