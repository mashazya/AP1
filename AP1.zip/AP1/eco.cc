#include <iostream>
#include <vector>
using namespace std;

struct Casella {
    string e; // especie
    int v;    // vida
};

using Matrix = vector<vector<Casella>>;

void escriu (const Matrix& M,int n, int m){
	for(int i=1; i<=n; ++i){
		for(int j=1; j<=m; ++j){
			cout<<M[i][j].e<< " "<< M[i][j].v<<" ";
		}
		cout<<endl;
	}
	cout<<"****************************************"<<endl;

}
int calcula_vidas (const Matrix& M, int i, int j){
	int suma=M[i][j].v;
	int quatitat=1;
	if (M[i][j].e!=M[i-1][j].e) {
		suma=suma+M[i-1][j].v;
		++quatitat;
	}
	if (M[i][j].e!=M[i+1][j].e){
		suma=suma+M[i+1][j].v;
		++quatitat;
	}
	if (M[i][j].e!=M[i][j-1].e){
		suma=suma+M[i][j-1].v;
		++quatitat;
	}
	if (M[i][j].e!=M[i][j+1].e) {
		suma=suma+M[i][j+1].v;
		++quatitat;
	}
	int mitjana = suma/quatitat;
	return mitjana;
	
}


bool comprova(const Matrix& M, int n, int m){
	bool igual=true;
	
		for (int i=1; i<=n and igual; ++i){
			for (int j = 1; j<m; ++j){
				if (M[i][j].v!=M[i][j+1].v)igual=false;
			}
		}
	
	return igual;
}

Matrix estabilitza(Matrix& M,int n, int m){

		for (int i=1; i<=n; ++i){
			for (int j=1; j<=m; ++j){
				M[i][j].v=calcula_vidas(M,i,j);
			}
		}
return M;
	
}



int main (){
	int n,m;
	cin>>n>>m;
	Matrix M (n+2,vector<Casella>(m+2));
	for(int i=1; i<=n; ++i){
		for(int j=1; j<=m; ++j){
			cin>>M[i][j].e>>M[i][j].v;
		}
	}

	Matrix M1 =estabilitza (M,n,m);
	Matrix M2 =estabilitza (M1,n,m);
	escriu(M,n,m);

	

}
