#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<char>>;

void escriu (const Matrix & T, int n, int m){
	for (int i = 1; i<=n; ++i){
		for (int j = 1; j<=m; ++j){
			cout<< T[i][j];
		}
		cout<<endl;
	}
}


int comprova_vei(Matrix& M, int i, int j, int n, int m){
	int B=0;
		if (M[i-1][j-1]=='B')++B;
		if (M[i-1][j]=='B')++B;
		if (M[i-1][j+1]=='B')++B;
		if (M[i][j-1]=='B')++B;
		if (M[i][j+1]=='B')++B;
		if (M[i+1][j-1]=='B')++B;
		if (M[i+1][j]=='B') ++B;
		if (M[i+1][j+1]=='B') ++B;

	if (B>3) return 4;
	return B;
}


void game_of_life (int n, int m, Matrix& M){
	Matrix T (n+2, vector <char> (m+2,'.'));
	for (int i = 1; i<=n; ++i){
		for (int j=1; j<=m; ++j){
			int vei = comprova_vei(M, i, j, n, m);
			
			if (M[i][j]=='.'){
				if (vei == 3) T[i][j]='B';
			}
			if (M[i][j]=='B'){
				if (vei == 3 or vei == 2) T[i][j]='B';
			}

		}
	}
	escriu (T, n, m);
}

int main (){
	int n,m;
	int i=0;
	while (cin>>n>>m and n!=0 and m!=0){
		if (i>0) cout<<endl;

		Matrix M (n+2, vector<char>(m+2));
		for (int i= 1; i<=n; ++i){
			for (int j=1; j<=m; ++j){
				cin>> M[i][j];
			}
		}
		game_of_life(n,m,M);
		++i;
	}
}
