#include <iostream>
#include <vector>
using namespace std;

//si digit='u' >> unitats
//digit='d' >>desenes
//digit='c'>> centenes
//digit='m'>> milers
void escriu_digit(int n, char digit){
	char c1, c5, c10;
	//quan acabi el programa imprimirem c1>>c5>>c10

	if (digit=='u'){
		c1='I';
		c5='V';
		c10='X';

	}

	if (digit=='d'){
		c1='X';
		c5='L';
		c10='C';
		
	}

	if (digit=='c'){
		c1='C';
		c5='D';
		c10='M';
		
	}
	else c1= 'M';

	if (n==1) cout<<c1;
	else if (n==2) cout<< c1 <<c1;
	else if (n==3) cout << c1<< c1<< c1;
	else if (n==4) cout<<c1<<c5;
	else if (n==5) cout<<c5;
	else if (n==6) cout<<c5<<c1;
	else if (n==7) cout<<c5<<c1<<c1;
	else if (n==8) cout<<c5<<c1<<c1<<c1;
	else if (n==9) cout<<c1<<c10;
	cout<<endl;


}
void escriu_en_roma(int n){
	cout<<n<<" = ";
	int unitats  = n%10;
	n=n/10;

	int centenes = n%10;
	n=n/10;

	int desenes = n%10;
	n=n/10;

	int milers=n;

	escriu_digit(milers,'m');
	escriu_digit(centenes,'c');
	escriu_digit(desenes,'d');
	escriu_digit(unitats,'u');

}





