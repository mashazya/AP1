#include <vector>
#include <iostream>
using namespace std;

void escriu (const vector <int>&v){
	int i = 0;
	for (int x: v){
		if (i>0) cout<< " ";
		cout << x;
		++i;
	} 
	cout<<endl;
}

void genera (vector<int>&v, int i, int o, int contador_zeros, int contador_uns, int aux){
	int n =v.size();
	if (i==n){
		escriu(v);
	}
	else{
		if (contador_zeros < n-o){
			v[i]=0;
			++ contador_zeros;
			genera(v,i+1,o,contador_zeros,contador_uns,aux);
			--contador_zeros;
			++aux;
		}
		if (contador_uns < o){
			v[i]=1;
			++contador_uns;
			genera(v,i+1,o,contador_zeros,contador_uns,aux);
			++aux;
		}
	}


}

int main (){
	int n,o;
	cin>>n>>o;
	vector<int> v(n);

	genera(v,0,o,0,0,0);
}

