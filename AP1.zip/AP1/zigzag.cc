#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

using Matrix=vector<vector<int>>;

bool es_creixent(const Matrix & T, int files, int columnes){

	for (int i = 0; i<files; ++i){
		for (int j=0; j<columnes; ++j){

			if (j+1<columnes){
				if (T[i][j]>=T[i][j+1]) return false;
			}
			else if (j+1==columnes and i+1<files){
				if (T[i][j]>=T[i+1][0]) return false;
				++j;
			}
		}
	}
	return true; 

}

void trasposada_zigzag(const Matrix & M, int n, int m){
	//n,m fil col de la matriu M
	int files, columnes; //matriu T
	files=m;
	columnes=n;
	Matrix T (files, vector<int>(columnes));
	int j=0;
	while(j<m){
		for (int i=0; i<n; ++i){
			T[j][i]=M[i][j];

		}
		++j;
		if (j<m){
			for (int i = n-1; i>=0; --i){
				T[j][columnes-1-i]= M[i][j];

			}
			++j;
		}
	}
	
	if (es_creixent(T, files, columnes)) cout<<"yes"<<endl;
	else cout<< "no"<<endl;

}

int main(){
	int files, columnes;
	int i = 1;
	while(cin >> files>>columnes){
		
		Matrix M (files, vector<int>(columnes));
		for (int i=0; i<files; ++i){
			for (int j = 0; j<columnes; ++j){
				cin>> M[i][j];
			}
		}

		cout<< "matriu "<< i << ": ";
		trasposada_zigzag(M,files,columnes);
		++i;
	}
}





