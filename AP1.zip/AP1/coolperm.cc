#include <iostream>
#include <vector>
using namespace std;


void escriu (const vector<int>& permutacio){
	for (int i =0; i<permutacio.size(); ++i){
		if (i!=0) cout<<" ";
		cout<<permutacio[i];
	}
	cout<<endl;
}


void comprova (const vector<int>& permutacio){
	bool consecutius=false;
	for (int i =0; i<permutacio.size()-1 and not consecutius;++i){
		if (permutacio[i]==permutacio[i+1]+1 or permutacio[i]==permutacio[i+1]-1){
			consecutius=true;
		}
	}
	if (not consecutius) escriu (permutacio);

}


void genera (vector<int>& permutacio, vector <bool>& usat, int i){
	int n= permutacio.size();
	if (i==n){
		return comprova(permutacio);
	}
	for (int j = 0; j<n; ++j){
		if (not usat[j]) {
			permutacio[i]=j;
			usat[j]=true;
			genera (permutacio,usat,i+1);
			usat[j]=false;
		}
	}

}



int main (){
	int n;
	while(cin>>n){
		vector<int>permutacio(n);
		vector <bool> usat(n+1);
		genera(permutacio,usat,0);
		cout<<"********************"<<endl;
	}

}