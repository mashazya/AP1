#include <iostream>
using namespace std;


int main () {
	int n;
	int a;
	bool pic = false;
	cin>>n;
	a=n;
	while (cin>>n and n!=0 and a!=0){
		
		if (n>3143){
			if (n>a ){
				cin >> a; 
				if (n>a and a!=0) pic = true;
			}
		}
		else a=n;
	}
	if (pic == false) cout << "NO" << endl;
	if (pic) cout << "YES" << endl;

}

while (n>0){
			cout << "  /"<< "\\";
			--n;
			
		}
		cout << endl;
		while (i>0 ){
			cout << "/" << "__" << "\\";
			--i;
			
		}
		cout << endl;
