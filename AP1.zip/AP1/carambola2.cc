#include <iostream>
#include <vector>
using namespace std;
typedef vector< vector <char> > Tablero;

typedef vector< vector <char> > Tablero;

struct Bola {
	int x_ant, y_ant;
	int x_act, y_act;
	int x_sig, y_sig;
};

void escriure (const Tablero& t, int n, int m, bool carambola){
	cout<< ":";
	if (carambola) cout << " si"<<endl;
	else cout<< " no"<<endl;
	for (int i=0; i<n; ++i){
		for (int j=0; j<m; ++j){
			cout<< t[i][j];
		}
		cout<<endl;
	}
	cout<<endl;

}

bool esquina (int i, int j,int n, int m){
	return (i==0 and j==0) or (i==0 and j == m-1) or (i==n-1 and j==0) or (i==n-1 and j==m-1);
}
bool bandas (int i, int j, int& contador, int n, int m){
	if (i==0 or i==n-1 or j==0 or j==m-1) {
		if (contador > 0)cout << "(" << i<<","<<j<<")";
		++contador;
	}
	return contador > 4;

}

void mover_hasta_chocar (Tablero& t, Bola& b){
	int n=t.size();
	int m=t[0].size();
	int i=b.x_act;
	int j = b.y_act;
	int contador = 0;
	int x1=i;
	int y1=j;
	int hor = 0;
	int vert = 0;
	t[i][j]='=';
	while ((not esquina(i,j, n,m) or (i==x1 and j==y1)) and t[i][j]!='b' and not bandas(i,j,contador, n, m)){
		if (i==n-1) vert = -1;
		if (i==0) vert = 1;
		if (j==0) hor = 1;
		if (j==m-1) hor = -1;

		i=i+vert;
		j=j+hor;

		if(t[i][j]!='b') t[i][j]='=';


	}


	b.x_act=i;
	b.y_act=j;

	b.x_ant= b.x_act -vert;
	b.y_ant= b.y_act - hor;

	if (esquina(i,j, n,m)){
		b.x_sig=b.x_act;
		b.y_sig=b.y_act;
	}
	else {
		b.x_sig=b.x_act+vert;
		b.y_sig=b.y_act+hor;
	}

	t[b.x_act][b.y_act]='B';

	bool carambola = false;
	 if (t[i][j]!='b' and contador==4) carambola=true;


	escriure (t,n,m,carambola);

}


int main (){
	int n,m;
	while(cin >> n>>m){
		Tablero t (n, vector<char> (m,'.'));
		Bola b;

		int x1, y1;
		cin >> x1 >> y1;
		b.x_act = x1;
		b.y_act = y1;

		int x2, y2;
		cin >> x2 >> y2;
		t[x2][y2]='b';

		mover_hasta_chocar(t,b);
	}

}



