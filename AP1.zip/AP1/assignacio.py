from jutge import read

a,b = read (int, int)

x,y = y,x #assignacio multiple

