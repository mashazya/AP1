#include <iostream>
#include <vector>
using namespace std;


int position(double x, const vector<double>& v, int left, int right){
    if (left>right) return -1;
    int mig = (left+right)/2;
    if (left<=right){
        if (v[mig] == x) return mig;
        if (v[mig]>x) {
            right = mig-1;
            return position (x,v,left,right);
        }
        else {
            left = mig+1;
            return position (x,v,left,right);
        }
    }
    return -1;
}


int main() {
    int n;
    while (cin >> n) {
        vector<double> V(n);
        for (int i = 0; i < n; ++i) cin >> V[i];
        int left, right;
        double x;
        cin >> x >> left >> right;
        cout << position(x, V, left, right) << endl;
    }
}
