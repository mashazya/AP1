#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
using Matrix = vector<vector<char>>;


void patron (int n, int size, Matrix& M, int i, int j){
	if (n==1) M[i][j] = '#';
	else {
		patron (n-1, size, M, i, j);
		patron (n-1, size, M, i, j+pow(2,n-1));
		patron (n-1, size, M, i+pow(2,n-1), j);
		patron (n-1, size, M, i+pow(2,n-1), j+pow(2,n-1));
		M[i][j+pow(2,n-1)-1]='#';
		M[i+pow(2,n-1)-1][j]='#';
		M[i+(pow(2,n-1)-1)][j+2*(pow(2,n-1)-1)]='#';
		M[i+2*(pow(2,n-1)-1)][j+pow(2,n-1)-1]='#';


	}
}

int main(){
	int n;
	cin>>n;
	int k = pow(2,n)-1;
	Matrix M (k, vector<char>(k,'.'));
	patron (n,k, M,0,0);
	for (int i = 0 ; i<k; ++i){
		for (int j = 0; j<k; ++j){
			cout<<M[i][j];
		}
		cout<<endl;
	}


}