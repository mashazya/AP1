#include <iostream>
#include <vector>
using namespace std;


void product_digits (int  n, int p){
	if (n/10 > 0){
		cout<< "The product of the digits of " << n << " is ";
		while (n>0){
			p=p*(n%10);
			n=n/10;
		}
		cout << p<< "." << endl;
		product_digits(p,1);
	}
}

int main(){
	int n;
	while(cin>>n){
		if (n>=10) product_digits(n, 1);
		else cout<< "The product of the digits of " << n << " is "<< n<< "." << endl;
		cout<< "----------"<<endl;
	}

}