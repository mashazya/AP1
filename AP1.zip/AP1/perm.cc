#include <iostream>
#include <vector>
using namespace std;

void escriu(const vector <int>& v){
	cout<<"(";
	int i = 0;
	for (int x: v){
		if (i>0) cout<<",";
		cout<<x;
		++i;
	}
	cout<<")"<<endl;

}

void genera (vector <int>& v, int i, vector <bool>& permutacio ){
	int n=v.size();
	if (i==n){
		escriu(v);
	}
	else{
		for (int j=1; j<=n; ++j){
			if (not permutacio[j]){
				v[i]=j;
				permutacio[j]=true;
				genera(v,i+1,permutacio);
				permutacio[j]=false;
			}
		}

	}
	
}

int main (){
	int n;
	cin>>n;
	vector <int> v (n);
	vector <bool> permutacio (n+1,false);
	genera (v,0,permutacio);
}
