#ordenacio per fusio python
from jutge import read
import random

def primers(n):
	#a cada posicio del vector hi ha un bool que diu si el numero esta tachat
	p=[True for i in range (n+1)]
	p[0] = False
	p[1] = False
	i = 2
	while i*i <= n:
		if p[i]:
			j = i+i
			while j<= n:
				p[j] = False
				j=j+i
		i=i+1
	return p

def main ():

	n = read(int)
	p = primers(n)
	lp = []
	for i in range (n+1):
		if p[i]:
			lp.append(i)
	print (lp)

main ()