#include <iostream>
#include <cassert>
using namespace std;


int sum_of_digits(int x){
	int sum;

	if (x>0){
		return sum= x%10 +sum_of_digits(x/10);
	}
	return false;
}


int reduction_of_digits(int x){
	
	if (x>0){
		x=sum_of_digits(x);
		if (x/10>0) return reduction_of_digits(x);
		return x;
	}
	return false;

}

int main (){
	int n;
	cin >> n;
	cout<< reduction_of_digits(n) <<endl;
	
}