#include <iostream>
#include <vector>
using namespace std;

void escriu(const vector <char>& v, int n){
	for (int i = 0; i<n; ++i){
		cout<< v[i];
	}
	cout<<endl;
}


void genera_paraules (int n, vector <char>& v,vector <bool>& used, int i){
	if (i==n) return escriu(v,n);
	for (int j = 0; j<n; ++j){
		if (not used[j]){
			if (i==0 or v[i-1]!='a'+j-1){
				v[i]='a'+j;
				used [j]=true;
				genera_paraules(n,v,used,i+1);
				used [j]=false;
			}
		}
	}

}

int main (){

	int n;
	cin>> n;
	vector <char> v (n);
	vector <bool> used (n,0);
	genera_paraules(n,v,used,0);
}