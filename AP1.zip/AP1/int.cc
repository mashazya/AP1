// 10 15 5 20

#include <iostream>
using namespace std;
int main() {


int a, b, c, d;
cin >> a >> b >> c >> d;
int x, y;

cout << "[" ;

	if ( b< c) cout << "]" << endl;
	else {



if (a >= c and d>=a){
	x = a;}

if (a<c and b>= c){
	x = c;}

// 10 18 18 30
if (b>=d ){
	if (b==c)
	y = b;
	else
	y = d;}

if (b<d){
	if (b==c)
	y = b;
	else
	y = b;}


if ((a >= c and a<= d) or (c>=a and c <=b)) cout << x << "," << y;

cout << "]" << endl;
	}
}