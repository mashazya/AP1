#include <iostream>
#include <vector>
#include <string>
#include <typeinfo>
#include <algorithm> 

using namespace std;

struct Paraula{
	string s;
	int repe;
};

bool ordena (const Paraula& a, const Paraula& b){
	if (a.repe!=b.repe) return a.repe < b.repe;
	else return a.s < b.s;
}

void conta_paraules(vector <Paraula>& paraules){
	sort (paraules.begin(),paraules.end(), ordena);
	int n = paraules.size();
	cout << paraules[n-1].s<<endl;
}


void largest_word(vector <string>& s, int n){
	sort (s.begin(), s.end());
	vector <Paraula> paraules(0);
	paraules.push_back({s[0],1});
	int i = 1;
	int j = 0;
	while (i<n){
		if (s[i]==s[i-1]) ++paraules[j].repe;
		else {
			paraules.push_back({s[i],1});
			++j;
		}
		++i;
	}
	conta_paraules(paraules);


}

int main (){
	int n;
	cin>>n;
	
	vector <string> s (n);
	for (int i=0; i<n; ++i){
			cin>>s[i];
		}

		largest_word(s,n);

		cin>>n;

	}
}
