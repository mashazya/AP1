#include <iostream>
using namespace std;

int main () {
int i=1;
int f=0;
int c;
while (cin >>c and f == 0){
	if (c%2!=0)++i;
	else if (c%2==0){
		f=i;
	}	
}
cout << f << endl;
}