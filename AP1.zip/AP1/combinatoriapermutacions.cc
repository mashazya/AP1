#include <vector>
#include <iostream>
using namespace std;

void escriu (const vector <int>&v){
	for (int x: v) cout << x;
	cout<<endl;
}

void genera (vector<int>&v,vector<bool>& u, int i){
	int n =v.size();
	if (i==n){
		escriu(v);
	}
	else{
		for (int c = 0; c<n; ++c){
			if (not u[c]){
				v[i]=c;
				u[c]=true;
				genera(v,u,i+1);
				u[c]=false;

			}
		}
	}


}

int main (){
	int n;
	cin>>n;
	vector<int> v(n);
	vector<bool> u(n,false)

	genera(v, 0);
}