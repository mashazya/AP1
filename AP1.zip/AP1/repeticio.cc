// conta les repeticions de xifres consecutives en un numero
// 3445667
//r=2;


#include <iostream>
using namestape std;
int main (){
	int r = 0;
	int a;
		if (cin >> a) { // llegeix la primera a
			int b; // la seguent xifra = b;
			while (cin >> b){ 
				if (b==a) ++r; //compara si a i b son iguals i suma 1 a r si ha trobat una repeticio
				a=b;
			}

		}
		cout << r << endl;
}