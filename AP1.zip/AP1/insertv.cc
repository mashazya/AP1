#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


void insert(vector<double>& v){
    int n = v.size();
    if (v[n-1]<v[n-2]){
        for (int i=n-1; i>0; --i){
            if (v[i]<v[i-1])swap (v[i],v[i-1]);
        }
    }

}


int main() {
    cout.setf(ios::fixed, ios::floatfield);
    cout.precision(4);
    int n;
    while (cin >> n) {
        vector<double> V(n);
        for (int i=0; i<n; ++i) {
            cin >> V[i];
        }
        insert(V);
        for (int i=0; i<n; ++i) {
            cout << " " << V[i];
        }
        cout << endl;
    }
}
