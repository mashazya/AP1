#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


void posicions(const vector<int>& v, int& e, int& d){
	for (int i=0; i<v.size()-1; ++i){
		int j = i+1;
		if (v[i]>v[i+1]){
			while(j<v.size() and v[i]>v[j]){
				++j;
			}
			e=i;
			d=j-1;
			i=v.size();
		}
		else {
			e=0;
			d=0;
		}

	}

}


int main() {
  int n;
  while (cin >> n) {
    vector<int> v(n);
    for (int i = 0; i < n; ++i) cin >> v[i];
    int e,d;
    posicions(v,e,d);
  }
}
