#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

bool es_narcicista (int n){
	int copia = n;
	vector <int> v;
	while (n>0){
		v.push_back(n%10);
		n=n/10;
	}
	int suma=0;
	for (int i=0; i<v.size(); ++i){
		suma=suma+pow(v[i],v.size());
	}
	return suma==copia;
}



int main(){
	int n;
	bool narci=true;
	while (cin >> n){
		if(narci){
			if (not es_narcicista(n)) narci=false;

		}
	}
	
	if (narci) cout<<"SI"<<endl;
	else cout<< "NO"<<endl;



}









