#include <iostream>
using namespace std;

int main(){
    int n;
    cin >> n;
    int i = n;
    int x;
    int a;
    while (cin >> x and x!=-1) {
        --n;
        if (n==0) a=x;
    }
    cout << "At the position "  << i << " there is a(n) " << a << "." << endl;
}