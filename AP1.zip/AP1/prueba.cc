#include <iostream>
#include <vector>
using namespace std;

struct Point{
	int x;
	int y;
};

struct Segment{
	Point A;
	Point B;
};

using Polygon = vector<Point>;

int main(){
	Segment S;
	S.A.x=2;
	S.A.y=3;
	Polygon P(2);
	P[0]=S.A;
	P[1].x=S.A.x;
	P[1].y=S.A.y;


	cout<<"opcio 1" <<P[0].x<<P[0].y<<endl;
	cout<<"opcio 2" <<P[1].x<<P[1].y<<endl;

}
