#include <vector>
#include <iostream>
#include <string>
using namespace std;

/*vector <char> sequence (int m) {
	vector <char> code(m);
	int n;
	while (cin>>n){
		code.push_back(n);
	}
	return code;
}*/

void translate (int i, vector <char> code){
	int n = code.size();
	int k=0;

	while(i < (n-2)){
		if (k==26) {
			cout<<endl;
			k=0;
		}
		if (code [i] == 'U'){ 
			if (code [i+1]=='U'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "Phe";
				if (code [i+2]=='A' or code [i+2]=='G') cout<< "Leu";
			}
			if (code [i+1]=='C'){
				if (code [i+2]=='U' or code [i+2]=='C' or
				code [i+2]=='A' or code [i+2]=='G') cout<< "Ser";
				
			}
			if (code [i+1]=='A'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "Tyr";
				if (code [i+2]=='A' or code [i+2]=='G'){
					cout<<endl;
					return;
				}
				
			}
			if (code [i+1]=='G'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "Cys";
				if (code [i+2]=='A') {
					cout<<endl;
					return;
				}
				if (code [i+2]=='G') cout<< "Trp";
			}
		}
		if (code [i] == 'C'){ 
			if (code [i+1]=='U'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Leu";
			}
			if (code [i+1]=='C'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Pro";
				
			}
			if (code [i+1]=='A'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "His";
				if (code [i+2]=='A' or code [i+2]=='G') cout <<"Gln";
				
			}
			if (code [i+1]=='G'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Arg";
			}
		}
		if (code [i] == 'A'){ 
			if (code [i+1]=='U'){
				if (code [i+2]=='U' or code [i+2]=='C' or code[i+2]=='A') cout<< "Ile";
				if (code [i+2]=='G') cout<< "Met";
			}
			if (code [i+1]=='C'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Thr";
				
			}
			if (code [i+1]=='A'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "Asn";
				if (code [i+2]=='A' or code [i+2]=='G') cout <<"Lys";
				
			}
			if (code [i+1]=='G'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "Ser";
				if (code [i+2]=='A' or code [i+2]=='G') cout <<"Arg";
			}
		}
		if (code [i] == 'G'){ 
			if (code [i+1]=='U'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Val";
			}
			if (code [i+1]=='C'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Ala";
				
			}
			if (code [i+1]=='A'){
				if (code [i+2]=='U' or code [i+2]=='C') cout<< "Asp";
				if (code [i+2]=='A' or code [i+2]=='G') cout <<"Glu";
				
			}
			if (code [i+1]=='G'){
				if (code [i+2]=='U' or code [i+2]=='C' or code
				[i+2]=='A' or code [i+2]=='G') cout<< "Gly";
			}
		}
		i=i+3;
		++k;
	}

}

void search_AUG (vector <char> code){
	int n = code.size();
	for (int i = 0; i<n; ++i){
		if (code[i] == 'A' and code [i+1] == 'U' and code [i+2]== 'G'){
			return translate(i+3, code);
		}
	}

}

int main (){
	char c;
	while (cin >> c and c!= ':'){
	}

	vector <char> code;
	char n;
	while (cin>>n){
		code.push_back(n);
	}
	search_AUG (code);
}



