from jutge import *


def min_Max(M):
	n = len (M)
	mM = []
	for i in range (n):
		mM.append([0]*2)

	for i in range (n):
		x=[]
		for j in range (n):
			x.append(M[j][i])

		mM[i][0]=min(M[i])
		mM[i][1]=max(x)

	return mM




