#include <iostream>
using namespace std;

int main(){

    int n;
    cin >> n;
    int i=n;
    int x;
    int a;
    while (cin >> x and x!=-1) {
        --i;
        if (i==0) a=x;
    } 

    if (n<=0 or i>0) cout << "Incorrect position." <<endl;
    else cout << "At the position " << n << " there is a(n) " << a << "." << endl;
}