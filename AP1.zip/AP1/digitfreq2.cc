#include <iostream>
#include <vector>
#include <cmath>
#include  <algorithm>
using namespace std;

void canviar_base(vector <int> & nombres, int b, int n){
	if (n>0){
		int s = n%b;
		++nombres[s];
		canviar_base(nombres,b,n/b);
	}
}

void busca_max (vector <int>& nombres){
	int max=0;
	int imax=0;
	for(int i=0; i<nombres.size(); ++i){
		if (nombres[i]>max) {
			imax=i;
			max=nombres[i];
		}
	}
	cout<<imax<<" "<<max<<endl;
}

/*void nombre_frequent (const vector <int>& nombres, vector <int>& xifra){
	int n = nombres.size();
	for (int i = 0; i<n; ++i){
		int k = nombres[i];
		if (k==0) ++xifra[0];
		while(k>0){
			++xifra[k%10];
			k=k/10;
		}

	}
	compara(xifra);

}*/

int main() {

	int b,k;
	cin>>b;
	vector <int> nombres(10,0);
	while (cin>>k){
		if (k==0) ++nombres[0];
		canviar_base(nombres,b,k);
	}
	busca_max(nombres);

}