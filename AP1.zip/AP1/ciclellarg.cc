#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


void cicle (vector <int> v, int n){
	int max = 0;
	vector <bool> pos (n,false);
	for (int k = 0; k<n; ++k){
		int contador=0;
		if (not pos[k]){
			int i=k;
			int j = i+1;
			while (v[i]!=j){
				pos[i]=true;
				i=v[i]-1;
				++contador;
			}
			if (contador>max) max = contador;
		}
	}
	cout<<max+1<<endl;

}

int main() {
  int n;
  while (cin >> n) {
    vector<int> v(n);
    for (int i = 0; i < n; ++i) cin >> v[i];
    cicle(v,n);
  }
}
