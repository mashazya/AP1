#include <iostream>
using namespace std;

int main (){
	int a,b,c;
	int i = 0;
	int n;
	cin >> n;
	while (n>0){
		cin>>a;
		if (a!=-1) {
			cin >>b;
			while (b!=-1 and cin>>c and c!=-1){
				if (b+c < a+b) ++i;
				a=b;
				b=c;
			}
		}
		cout<< i<< endl;
		--n;
		i=0;
	}
}
		
		
	