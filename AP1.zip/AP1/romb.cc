#include <iostream>
using namespace std;
int main() {


int x;
cin >> x;
int n = 1;
int a = x;
int j = 1;
int k= x-j;
int c=0;



	while (n < a and a>0) {
	cout << " ";
	n = n+1;
	
		if (n == a) {

			for (int i=k; i<x and j<=x; ++i){
			cout <<"*";
			c = c+1;
				if (c > x-(x-1)) cout << "*";
			}
			

			a = a-1;
			n = 1;
			j=j+1;
			k= x-j;
			cout << endl;
			c = 0;

		}
	}

		a= x + (x-1);
		while (a>0){
		cout << "*";
		a = a-1;
		}

		cout << endl;


int m = 1;
int l = x-1;
int i = 0;
k = x;
c = 1;


		
	while (m > 0 and l>0) {
	cout << " ";
	m = m-1;

		if (m == 0) {

			for (int p = 1; p<x; p++){
				cout << "*";
				c = c+1;
				if (c < x) cout << "*";
				
			}
		--x;
		c=1;

		cout << endl;
		i=i+1;
		m = i + 1;
		l=l-1;

		}
	}
		




	
}