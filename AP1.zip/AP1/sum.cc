#include <iostream>
using namespace std;

int main (){
	int a;
	int sum = 0;
	
	while (cin >> a ){
		cout << "The sum of the digits of " << a << " is ";
		while (a>0){
			sum = sum+a%10;
			a = a/10;
		}
		cout << sum << "." << endl;
		sum = 0;
	}
}