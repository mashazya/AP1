from jutge import *

def three_equal_consecutive_digits(n, b):
	contador =0
	if n<b: return False
	else:
		aux = n
		x1= aux%b
		aux=aux//b

		x2= aux%b
		aux=aux//b

		x3= aux%b
		aux=aux//b

		if x1==x2 and x2==x3: return True
		else: return three_equal_consecutive_digits(n//b,b)