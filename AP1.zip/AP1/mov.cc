#include <iostream>
#include <iomanip>
using namespace std;



int main (){

char a;

int x = 0;
int y = 0;

while (cin >> a){
	if (a == 'n') y = y-1;
	if (a == 's') y = y+1;

	if (a == 'e') x = x+1;
	if (a == 'w') x = x-1;

}


cout << "(" << x << "," << " " << y << ")" << endl;
}