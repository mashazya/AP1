from jutge import read

def mitjana(L):
	s=0
	for x in L:
		s=s+x #suma dels elements del vector
	return s/len(L)

def escalar (v,c):
	for x in range (len(v)):
		v[i] = v[i]*c
		c=9 #canvia el valor de c pero no del cc passat per referencia a la funcio
		print (v)


x=[1,2,3]
cc=2
escalar (x,cc)
