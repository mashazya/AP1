#include <iostream>
using namespace std;

void fila (int k,int i){
	
	while (k>0){
			cout<<i;
			--i;
			if (i== -1) i=9;
			--k;
		}
}

void quadrat (int n){
	int a=0;
	int k=n;
	int i;
	while(a<=n and n>0){
		if (n>10){
			while (n/10>1){
				n=n/10;
			}
			i=n;
		} 
		else i = n-1;
		
		fila(k,i);
		cout << endl;
		++a;
		int x=a;

		while (x>0){
			
			--x;
			cout<<n-2;

		}
		
		--n;
		k=k-1;
		
		
	}
	cout << endl;
}

int main (){
	int n;
	cin>>n;
	quadrat (n);

}