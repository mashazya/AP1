#include <typeinfo>

#include <iostream>    
#include <string>    
#include <vector>    
using namespace std;

struct Province {
    string name;
    string capital;
    int population;
    int area;
    double gdp;
};
struct Country {
    string name;
    string capital;
    vector<Province> provs;
};

typedef vector<Country> Countries;

double gdp(const Countries& p, char c, double d){
    double suma =0;
    int n=p.size();
    for (int i = 0; i<n; ++i){
        if (p[i].name[0]== c){
            int m=p[i].provs.size();
            for (int j=0; j< m; ++j){
                if (p[i].provs[j].area != 0){
                    double densitat = double(p[i].provs[j].population)/double(p[i].provs[j].area);
                    if (densitat > d) suma = suma + p[i].provs[j].gdp;
                }
            }
        }
    }
    return suma;
}


int main () {
    int n;
    cin >> n;
    Countries p(n);
    for (int i=0; i<n; ++i) {
        int np;
        cin >> p[i].name >> p[i].capital >> np;
        p[i].provs = vector<Province>(np);
        for (int j=0; j<np; ++j) {
            cin >> p[i].provs[j].name >> p[i].provs[j].capital >> 
                p[i].provs[j].population >> p[i].provs[j].area >> 
                p[i].provs[j].gdp;            
        }
    }
    cout << gdp(p,'A',10) << endl;
    cout << gdp(p,'A',20) << endl;
    cout << gdp(p,'A',30) << endl;
    cout << gdp(p,'A',40) << endl;
    cout << gdp(p,'E',10) << endl;
    cout << gdp(p,'E',20) << endl;
    cout << gdp(p,'E',30) << endl;
    cout << gdp(p,'E',40) << endl;
    cout << gdp(p,'C',40) << endl;
}
