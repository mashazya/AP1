#include <iostream>
#include <vector>

using namespace std;

int posicio(int x, const vector <int>& v){
	int n=v.size ();
	for (int i = 0; i<n; ++i){
		if (v[i] == x){
			return i;
		}
		if (v[i] > x) return -1;
	}
	return -1;

}

int main (){
	vector <int> v = {3, 5, 5 ,8, 9, 12, 15}
	cout << posicio (9,v) << endl;

}
