#include <iostream>
using namespace std;
int main() {


int x;
cin >> x;
int n=x;
int i;
while (n > 0) {
n = n/10;
i= i+1;
}





if (x>0) cout << "The number of digits of " << x << " is " << i << "." << endl;
else cout << "The number of digits of " << x << " is " << "1" << "." << endl;

}