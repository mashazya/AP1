#include <iostream>
using namespace std;

bool es_xupiguai(int n, int b){
	if (n==0) return true;
	int k,m;
	m = n%b;
	k = (n/b)%b;
	if (m>=b/2 and k<b/2) return es_xupiguai(n/(b*b),b);
	return false;

}

int main (){
	int n,b;
	cin>> n>>b;
	cout << es_xupiguai(n,b)<< endl;
}