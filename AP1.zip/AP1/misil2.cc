#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<char>>; 

void write (Matrix M, int f, int c){
	for(int i=0; i<f; ++i){
		for(int j= 0; j<c; ++j){
			cout<< M[i][j];
		}
	cout<<endl;
	}
}

void misil (Matrix& M, int f, int c, int i, int j,bool toca){
	while (not (i>=f-1 and j>=c-1) and not (i==0 and j==c-1) and not (i==f-1 and j==0)){
		while(i<f-1 and j<c-1){
			++i;
			++j;
			M[i][j] = 'X';
		}
		if (i==0 and j!=c-1){
			cout<<"here";
			while (j!=c-1 and i!=0){
				--i;
				++j;
				M[i][j] = 'X';
			}
			if (i==0) return misil (M,f,c,i,j,toca);
			else while (i>0){
				--i;
				--j;
				M[i][j] = 'X';
			}
		}
	}
	write(M,f,c);
}

int main(){
int f,c;
cin>>f>>c;
Matrix M (f, vector<char>(c));
for (int i=0; i<f; ++i){
	for (int j=0; j<c; ++j){
		M[i][j] = '.';
	}
}
bool toca=false;

misil(M,f,c,-1,-1,toca);
}


