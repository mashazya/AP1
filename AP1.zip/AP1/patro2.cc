#include <iostream>
using namespace std;


void patro (char n) {
	if (n=='a') cout<< "a";
	else {
		cout << n;
		int k = n - 'a';
		for (int i = 0; i<k; ++i){
			patro(n-1);
			cout<< n;
		}
	}

	
}
int main (){
	char n;
	cin >> n;
	patro (n);
	cout<<endl;
}