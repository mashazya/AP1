#include <iostream>
using namespace std;

void triangle_up (int n){

	cout << "/" << "\\";
}

void triangle_dw (int n){

		cout << "/" << "__" << "\\";

}
	
void escriu_triangle(int t){
	int a = t-1;
	int p=0;
	int l = 0;
	int y = 1;


			while (t-a <= t){
				p=0;
				l=0;
				int i=y;
				int h = y+1;

				while(i<t*2){
					i=i+1;
					cout << " ";
				}
				while (l < t- a){

					if (l!=0) cout << "  ";

					triangle_up(t);
					++l;
				}
				cout<<endl;

				while(h<t*2){
					h=h+1;
					cout << " ";
				}
				while (p < t- a){
					triangle_dw(t);
					++p;
				}
				
				--a;
				y=y+2;
				cout<<endl;
			}
			cout << endl;

}
int main () {
	int t;
	while (cin >> t and t!=-5 and t!=0){
		escriu_triangle (t);
	}
}

