#include <iostream>
#include <cmath>
using namespace std;

int num_dig (int n){
	int i=0;
	while (n > 0) {
		n = n/10;
		i= i+1;
	}
	return i;
}


bool es_capicua(int n, int b){
	cout<< "n="<<n<<endl;
	int m,k;
	int x=n;
	while (x>0){
		k=x%b;
		cout<< ".k="<<k<<endl;
		x=(x/b)%(int pow(10,num_dig(x)-1));
		cout<< ".x="<<x<<endl;
	}
	m = n%b;//ultima
	cout<< "m="<<m<<endl;
	
	if (n>0){
		if (m==k) return es_capicua(n/b,b);
	}
	if (n==0 and m==k) return true;
	return false; 

}

int main (){
	int n,b;
	cin >> n>>b;
	cout<<es_capicua(n,b)<< endl;

}