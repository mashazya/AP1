#include <iostream>
using namespace std;


void sort3(int& a, int& b, int& c){
	int min=a;
	int min2=c;
	int d = b;
	if (b<a) {
		min = b;
		d=a;
		if (c>a) {
			min2=a;
			d=c;
		}
	}
	else {
		if (b<c){
		min2=b;
		d=c;
		}
	}

	if (min<min2) {
		a=min;
		b=min2;
	}
	else {
		a = min2;
		b = min;
	}
	c=d;
}	
	
int main (){
	int x, y, z;
	cin >> x >> y >> z;
	sort3 (x,y, z);
}