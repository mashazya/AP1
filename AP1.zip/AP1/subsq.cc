#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
using Matrix = vector<vector<int>>;

void busca_quadrats(int n, int m, const Matrix& M, int quadrats){
	int i=0;
	while(i+3<=n){
		int j=0;
		while (j+3<=m){
			bool sigue=true;
			vector <bool> hay(10,0);
			for (int k=i; k<i+3 and sigue; ++k){
				for (int p=j; p<j+3; ++p){
					
					if (not hay[M[k][p]]) hay[M[k][p]]=true;
					else sigue = false;
				}
			}
			if (sigue){
				++quadrats;
			}
			++j;
		}
		++i;
	}
	cout<<quadrats<<endl;
}



int main (){
	int n,m;
	while(cin >> n >>m){
		Matrix M (n, vector<int> (m));
		for (int i=0; i<n; ++i){
			for (int j=0; j<m; ++j){
				cin>> M[i][j];
			}
		}
		busca_quadrats(n,m, M,0);
	}
}