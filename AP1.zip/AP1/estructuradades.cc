#include <iostream>
using namespace std;

struct Time {
	int hour, minute, second;
 };

 Time incrementa_segon (Time& t){
 	++t.second;
 	if (t.second==60){
 		t.second=0;
 		++ t.minute;
 		if (t.minute==60){
 			t.minute=0;
 			++t.hour;
 			if (t.hour == 24) t.hour=0;
 		}
 	}
 	return t;
 }
 Time resta_segon (Time& t){
 	--t.second;
 	if (t.second==-1){
 		t.second=59;
 		-- t.minute;
 		if (t.minute==-1){
 			t.minute=59;
 			--t.hour;
 			if (t.hour == -1) t.hour=23;
 		}
 	}
 	return t;
 }

 void one_second(const Time& t, Time& t1, Time& t2){
 	t1=t;
 	t1=incrementa_segon(t1);
 	cout<<t1.hour<< " " << t1.minute << " " << t1.second<<endl;
 	t2=t;
 	t2=resta_segon(t2);
 	cout<<t2.hour<< " " << t2.minute << " " << t2.second<<endl;
 	
 }

 int main (){
 	Time t;
    while(cin >> t.hour >> t.minute >> t.second){
	 	Time t1, t2;
	 	one_second(t, t1, t2);
	 }

 }



