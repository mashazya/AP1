#include <iostream>
#include <vector>
using namespace std;


vector<double> difference(const vector<double> & V1, const vector<double> & V2){
  vector<double> aux;
  int n = V1.size();
  int m = V2.size();
  int contador = 0;
  //2 2 8
  // 3 4 6
  for (int i = 0; i<n; ++i){
    bool hay=false;
    int j=contador;
    if(V1[i]!=V1[i+1]){
      while(j<m and V1[i]>=V2[j] and not hay){
        if (V1[i]==V2[j]) {
          hay=true;
          contador=j;
        }
        ++j;
      }
      if (not hay) aux.push_back(V1[i]);
  }
  }
  return aux;
}

int main() {
  cout.setf(ios::fixed, ios::floatfield);
  cout.precision(4);
  int n1;
  while (cin >> n1) {
    vector<double> V1(n1);
    for (int i = 0; i < n1; ++i) cin >> V1[i];
    int n2;
    cin >> n2;
    vector<double> V2(n2);
    for (int i = 0; i < n2; ++i) cin >> V2[i];

    vector<double> res = difference(V1, V2);

    int n3 = res.size();
    cout << n3 << endl;
    for (int i = 0; i < n3; ++i) cout << " " << res[i];
    cout << endl << endl;

    for (int r = 0; r < 200; ++r) {
      vector<double> res2 = difference(V1, V2);
      
      if (res2 != res) cout << "Resultats diferents amb la mateixa entrada!" << endl;
    }
  }
}