#include <vector>
#include <iostream>
using namespace std;

typedef vector< vector<int> > Matrix;

bool suma_sudoku (const Matrix& M){
    vector <bool> v (9,false);
    int sumatotal = 0;
    for (int i = 0; i<9; ++i){
        int sum = 0;
        for (int j=0;j<9; ++j){
            v [M[i][j]-1]=true;
            sum = sum+M[i][j];
        }
        if (sum!=45) return false;
        for (int i=0; i<v.size(); ++i){
            if (v[i]==false)return false;
        }
    }
    for (int j = 0; j<9; ++j){
        int sum = 0;
        for (int i=0;i<9; ++i){
            sum = sum+M[i][j];
        }
        sumatotal = sumatotal+sum;
        if (sum!=45) return false;
    }
    if (sumatotal!=405) return false;
    else {
        int k = 0;
        int p = 0;
        int suma_square;
        while(k<=6 and p<=6){
            suma_square = 0;
            for (int i = k; i<k+3; ++i){
                for (int j=p; j<p+3; ++j){
                    suma_square = suma_square+ M[i][j];

                }
            }
            if (suma_square!=45) return false;
            p=p+3;
            if (p==9){
                k=k+3;
                p=0;
            }
        }
    }
    return true;
}



int main (){
    int n;
    cin>>n;
    int files = 9;
    int columnes = 9;
    Matrix A(files,vector<int>(columnes));
    while (n>0) {
        for (int i=0; i<files; ++i) {
            for (int j=0; j<columnes; ++j) {
                cin >> A[i][j];
            }
        }
        if (suma_sudoku(A)) cout<<"yes"<<endl;
        else if (not suma_sudoku(A)) cout<< "no" << endl;
        --n;
    }
}
