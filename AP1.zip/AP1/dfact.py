from jutge import read

def double_factorial (n):
	f=1
	i=n
	while i>0:
		f=f*i
		i=i-2
	return f

def main ():

	n=read(int)
	print(double_factorial (n))

main ()