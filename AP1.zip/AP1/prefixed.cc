#include <iostream>
#include <vector>
using namespace std;

int prefixed (){
	char c;
	cin >> c;//a cada crida recursiva llegin un caracter
	if (c >= '0' and c <= '9') return c-'0';//si llegim un numero el retornem
	else {
		if (c=='+') return prefixed() + prefixed ();
		else if(c=='-') return prefixed()-prefixed();
		else if (c=='*') return prefixed()*prefixed();
	}
}

int main(){
	int n = prefixed ();
	cout<< n <<endl;
}