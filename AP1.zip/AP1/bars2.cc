#include <iostream>
using namespace std;


void patro (int n){
	if (n==1) cout<< "*"<<endl;
	else {
		for (int i=0; i<n; ++i){
			cout<<"*";
		}
		cout<<endl;
		patro(n-1);
		patro(n-1);
	}
}

int main (){
	int n;
	cin>>n;
	patro (n);
}