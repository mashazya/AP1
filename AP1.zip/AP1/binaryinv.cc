#include <iostream>
using namespace std;
int main() {


int x;
cin >> x;
int n = x;

if (x == 0) cout << "0";

	while (n>=1){
	x = n % 2;
	cout << x;
	n = n/2;
	
	}

	cout << endl;
}