#include <vector>
#include <iostream>
using namespace std;

typedef vector< vector<int> > Matrix;

bool quadrat_magic (const Matrix& M, int n){
    int suma_horizontal = 0;
    int sum = 0;
    int suma_comparacio;
    for (int i = 0; i<n; ++i){
        if (i>0) suma_comparacio=sum;
        sum = 0;
        for (int j=0;j<n; ++j){

            sum = sum+M[i][j];

        }
        if (i>1 and suma_comparacio!=sum) return false;
        suma_horizontal = suma_horizontal+sum;
    }
    if (suma_horizontal!=n*sum) return false;


    //

    int suma_vertical = 0;
    for (int j = 0; j<n; ++j){
        if (j>0) suma_comparacio=sum;
        sum = 0;
        for (int i=0;i<n; ++i){

            sum = sum+M[i][j];
        }
        if (j>1 and suma_comparacio!=sum) return false;
        suma_vertical = suma_vertical+sum;
    }
    if (suma_vertical!=n*sum or suma_horizontal!=suma_vertical) return false;

    //

    int i = 0;
    int j = 0;
    int sumdiagonal1 = 0;
    while (i<n and j<n){
        sumdiagonal1=sumdiagonal1+M[i][j];
        ++i;
        ++j;
    }

    i=0;
    j=n-1;
    int sumdiagonal2 = 0;
    while (i<n and j>=0){
        
        sumdiagonal2=sumdiagonal2+M[i][j];
        ++i;
        --j;
    }
    if (sumdiagonal1 != sumdiagonal2 or sum!=sumdiagonal1 or sum!=sumdiagonal2) return false;

    return true;

    
}


int main (){
    int n;
    while(cin>>n){
        vector <int> v(n*n);
        int k = 1;
        bool repe = false;
        for (int i = 0; i<n*n; ++i){
            v[i]=k;
            ++k;
        }

        Matrix M (n,vector<int>(n));
        for (int i=0; i<n; ++i) {
            for (int j=0; j<n; ++j) {
                cin >> M[i][j];
                if (M[i][j]<=n*n){
                    int n = M[i][j];
                    v[n-1]=0;
                }
                else repe = true;
            }
        }
        for (int i = 0; i<n*n; ++i){
            if (v[i]!=0) repe = true;
        }
        if (not repe){
            if (quadrat_magic(M,n)) cout<<"yes"<<endl;
            else cout<< "no" << endl;
        }
        else cout<< "no" << endl;
    }

}
