#include <iostream>
using namespace std;
int main () {
	
	int n;
	cin >> n;

	int i = 0;
	int x = i;


	while (i<n) {
	x=i*i*i;
	cout << x << ",";
	i = i +  1;

	}

	
if (i==n) 
	x=i*i*i;
	cout << x << endl;




}