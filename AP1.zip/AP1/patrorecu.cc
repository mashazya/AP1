#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void patro (int n){
	if (n==1) cout<<1<<endl;
	else {
		patro(n-1);
		for (int i =0; i<n; ++i){
			if (i>0) cout<< " ";
			cout<<n;
		}
		cout<<endl;
		patro(n-1);
	}

}

int main(){
	int n;
	cin>>n;
	patro(n);



}

