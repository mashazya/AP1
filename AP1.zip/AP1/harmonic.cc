#include <iostream>
using namespace std;


double harmonic (double n){
	double h;
	h=(1/n);
	return h;
}

int main (){
	cout.setf(ios::fixed);
	cout.precision(10);

	int n,m;
	double h = 0;


	while (cin >> n >> m){
		m=m+1;

		while (m<=n){
			h=h+harmonic (m);
			++m;
		}
 
		cout << h<< endl;
		h=0;

	}

}