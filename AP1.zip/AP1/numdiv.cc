#include <iostream>
#include <vector>
#include <string>
#include <typeinfo>
#include <algorithm> 

using namespace std;


void divisors (vector<int>& factors, int n){
	int contador = 2;
	if (factors[n]!=n){
		while (n!=1){
			cout<<n<<"/"<<factors[n]<<"=";
			n=n/factors[n];
			cout<<n<<endl;
			++contador;
		}
	}
	cout<<contador<<endl;
}


void primers (vector <bool>& garbell, vector<int>& factors, int i){
	if (garbell[i]){
		for (int j = i; j<garbell.size(); j=j+i){
			garbell[j]=false;
			factors[j]=i;
		}
	}
	if (i<=garbell.size()) primers(garbell,factors,i+1);


}

int main (){
	int n;
	vector <bool> garbell (100001,true);
	garbell[0]=false;
	garbell[1]=false;
	vector<int> factors(1000001);
	factors[0]=0;
	factors[1]=1;
	primers(garbell,factors,2);
	while (cin>>n){
		divisors(factors, n);
	}
	
	
}
