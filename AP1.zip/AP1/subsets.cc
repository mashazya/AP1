#include <vector>
#include <iostream>
using namespace std;

void escriu (const vector <int>& permutacions,const vector <string>& v, int p){
	int m = v.size();
	int n = permutacions.size();
	for (int k = 1; k<=p; ++k){
		cout<< "subset " << k <<": "<<"{";
		int j = 0;
		for(int i=0; i<n; ++i){
			if (permutacions[i]==k){
				++j;
				if (j>1) cout<< ",";
				cout<< v [i];
			} 
		}
		cout<<"}"<<endl;
	}
	cout<<endl;
}

void genera (int i, int n, int p, vector <int>& permutacions, const vector <string>& v){
	if (i==n){
		return escriu(permutacions,v,p);
		//escriu_numeros(permutacions);
	}
	for (int j = 1; j<=p; ++j){
		permutacions[i]=j;
		genera(i+1, n, p, permutacions,v);
	}

}


int main (){
	int n,p;
	cin>>n;
	vector <string> v (n);
	for (int i = 0; i<n; ++i){
		cin>>v[i];
	}
	cin>>p;
	vector <int> permutacions(n);
	genera (0,n,p,permutacions,v);
}


