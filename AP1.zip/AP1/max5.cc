#include <iostream>
using namespace std;
int main () {


const int nombres = 50;
	int x;
	cin >> x;

	int m = x;
	int i = 0;
	while (i< nombres) {
		cin >> x;

		if (x>m) m=x;
		++i;


	}
	cout << m << endl;




}