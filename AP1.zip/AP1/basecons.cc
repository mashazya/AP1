#include <iostream>
#include <cmath>
using namespace std;

 bool three_equal_consecutive_digits(int n,int b){
	int i=0;
	int k;
	int m;

	while (n>0){
		k=(n/b)%b;
		m = n%b;
		if (m==k){
			++i;
			n= n/b;
		}
		if (m!=k){
			i=0;
			n= n/b;
		}
		if (i==2){
			return true;
		}
	}
	return false;
}
int main (){
	int n,b;
	cin>>n>>b;
	cout<< three_equal_consecutive_digits(n,b)<<endl;
	
}


