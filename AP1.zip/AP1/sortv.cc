#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int position_maximum(const vector<double>& v, int m){
    int max=0;
    for (int i = 0; i<=m; ++i){
        if (v[i]>v[max]) max = i;
    }
    return max;

}


void selection_sort(vector<double> & V, int m){
  if(m>0){
    swap (V[position_maximum(V,m)],V[m]);
    --m;
    selection_sort(V,m);
  }

}


int main() {
  cout.setf(ios::fixed, ios::floatfield);
  cout.precision(4);
  int m, n;
  while (cin >> m >> n) {
    vector<double> V(n);
    for (int i = 0; i < n; ++i) cin >> V[i];
    selection_sort(V, m);
    for (int i = 0; i < n; ++i) cout << " " << V[i];
    cout << endl;
  }
}


