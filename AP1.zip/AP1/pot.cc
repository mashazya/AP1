#include <iostream>
using namespace std;
int main () {
	int x, y;
	cin >> x >> y;
	int p = 0;

	while (y > 1) {
	p = p + (x * x);
	y = y - 1; }

cout << p << endl;
}