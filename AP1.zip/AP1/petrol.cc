#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void petrol_stations (vector <int>& stations, int x, int D, int n){
	int paradas=0;
	int distancia=x;
	for (int i=0; i<n+1; ++i){
		if (stations[i+1]-stations[i]>distancia) {
			++paradas;
			distancia=x;
		}
		distancia=distancia-stations[i+1]+stations[i];

	}
	cout<< paradas <<endl;

}

int main(){
	int x,D,n;
	while(cin>> x >> D >> n){
		vector <int> stations (n);
		for (int i = 0; i<n ; ++i){
			cin>>stations [i];
		}
		stations.push_back(0);
		stations.push_back(D);
		sort(stations.begin(), stations.end());
		petrol_stations(stations,x,D,n);
	}


}

