#include <iostream>
#include <sting>
#include <algorithm> // per que funcioni el swap
using namespace std;


// precondicio: el vector ha de estar ordenat de petit a gran
int subvector_nul_mes_llarg (const vector <int>&v, int& i, int& j) {
// sumer tots els element del vector i si la suma es mes gran que 0
// treiem un element del final
	int sum =0;
	for (int x:v) s = s+x;

	i=0;
	j= v.size()-1;//pq comença pel 0
	while (s!=0 and i<=j){
		if (s>0){
			s=s-v[j];
			--j;
		}
		else {
			s=s-v[i];
			++i;
		}

	}
}

int main (){

	vector <int> v = {7,-5,-4, -3, 8, 9};
	int i,j;
	subvector_nul_mes_llarg (v,i,j);
	if (i>j) cout << "no" << endl;
	else cout<< i << " " << j << endl;

	


}