#include <iostream>
#include <vector>
using namespace std;


vector<int> ex_union(const vector<int>& v1, const vector<int>& v2){
  int n = v1. size ();
  int m = v2.size ();
  vector <int> aux;
  int i=0, j=0;
  while (i<n and j<m){

    if (v1[i]==v1[i+1]){
      while (i<n-1 and v1[i]==v1[i+1])++i;
    }
    if (v2[j]==v2[j+1] ){
      while (j<m-1 and v2[j]==v2[j+1])++j;
    }

    if (v1[i]<v2[j]){
      while (v1[i]<v2[j] and i<n) {
        if (aux.size()==0)aux.push_back(v1[i]);
        else if (i==0 or v1[i]!=aux[i-1])aux.push_back(v1[i]);
      
        ++i;
      }
    }
    if (v1[i]>v2[j]){
      while (v1[i]>v2[j] and j<m) {
        if (aux.size()==0)aux.push_back(v2[j]);
        else if (j==0 or v2[j]!=aux[j-1])aux.push_back(v2[j]);

        ++j;
      }
      
    }
    if (v1[i]==v2[j]){
      ++i;
      ++j;
    }
  }
  if (i==n and j<m){
    while (j<m){

      if (j==0 or v2[j]!=aux[j-1])aux.push_back(v2[j]);
      ++j;
    }
  }
  else if (j==m and i<n){
    while (i<n){
      if (v1[i]==v1[i+1]){
        while (i<n-1 and v1[i]==v1[i+1])++i;
      }
      if (i==0 or v1[i]!=aux[i-1] )aux.push_back(v1[i]);
      ++i;
    }
  }
  return aux;

}

int main() {
  int n1;
  while (cin >> n1) {
    vector<int> v1(n1);
    for (int i = 0; i < n1; ++i) cin >> v1[i];
    int n2;
    cin >> n2;
    vector<int> v2(n2);
    for (int i = 0; i < n2; ++i) cin >> v2[i];
    vector<int> res = ex_union(v1, v2);

    if (res.size()>0) {
      for (int i=0; i<res.size(); ++i){
        cout<<res[i]<<" ";
      }
    }
    else cout<< "0"<<endl;
    cout<<endl;
  }

}
