#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n;
    bool suma = false;
    int sum = 0;
    while (cin >> n){
        vector <int> v(n);
        for (int i = 0; i< n; ++i){
            cin>>v[i];
            sum = sum +v[i];
        }
        for (int i=0; i<n; ++i){
            if (sum-v[i]==v[i]) suma=true;
        }
        if (suma)cout << "YES"<< endl;
        else if (not suma or (n<2 and v[0]!=0)) cout<< "NO" << endl;
        
        suma=false;
        sum = 0;
    }
      
}


