#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;


int main () {


cout.setf(ios::fixed);
cout.precision(4);

double x;
cin >> x;

double a;
int pot=0;
double p;
double r = 0;
while (cin >> a) {

	p = a * pow(x,pot);
	++pot;
	r = r+p;

}

cout << r << endl;

}